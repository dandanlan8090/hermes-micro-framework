---
name: media-creation-and-audio
description: "Music generation (Suno/heartmula), audio analysis (spectrograms, chroma, MFCC), generative image/3D (ComfyUI, p5js), animation (manim), ASCII art and video (image/video-to-ASCII), browser-based creative coding (pretext) — class-level guidance for creative media production."
version: 1.0.0
author: Hermes Agent (umbrella consolidation)
license: MIT
metadata:
  hermes:
    tags: [Music-Generation, Audio-Analysis, Image-Generation, Animation, ASCII-Art, Video, Creative-Coding, Generative-Art, Suno, ComfyUI, Stable-Diffusion, Manim]
    related_skills: [songwriting-and-ai-music, comfyui, manim-video, ascii-art, ascii-video, p5js, heartmula]
---

# Media Creation & Audio — Class-Level Guidance

This umbrella consolidates music generation, audio analysis, generative images,
3D/animation, ASCII conversion, and browser-based creative coding.

## Subsection Map

| What you need to do | Go to |
|---|---|
| Generate songs from lyrics + music tags | [Song Generation](#1-song-generation) |
| Analyze audio (spectrograms, mel-spectra, chroma, MFCC) | [Audio Analysis](#2-audio-analysis) |
| Generate images via Stable Diffusion / SDXL / Flux (ComfyUI) | [Generative Image / 3D (ComfyUI)](#3-generative-image--3d-comfyui) |
| Animate explanations (math, algorithms, physics) | [Math / Algorithm Animation (Manim)](#4-math--algorithm-animation-manim) |
| Convert images/video to colored ASCII | [ASCII Art & Video](#5-ascii-art--video) |
| Generative art, shaders, interactive visuals in the browser | [Browser Creative Coding (p5js / pretext)](#6-browser-creative-coding-p5js--pretext) |
| Write song lyrics, craft prompts for Suno | [Songwriting & AI Music](#7-songwriting--ai-music) |

## 1. Song Generation

See absorbed skill `heartmula` (formerly `media/heartmula`) for:
- Prompting Suno-style AI music generators
- Constructing lyrics + style tags + structure tags

## 2. Audio Analysis

See absorbed skill `songsee` (formerly `media/songsee`) for:
- Spectrogram generation from audio files
- Mel-spectrogram, chroma, MFCC extraction
- CLI-based audio feature visualization

## 3. Generative Image / 3D (ComfyUI)

See absorbed skill `comfyui` (formerly `creative/comfyui`) for:
- Install, launch, and manage ComfyUI (local + Comfy Cloud)
- Workflow execution via comfy-cli + REST / WebSocket API
- Image / video / audio generation via SD 1.5, SDXL, Flux, SD3
  AnimateDiff, Wan T2V, Hunyuan 
- Batch execution, img2img, inpainting
- Hardware check, dependency resolution, cloud fallback logic

## 4. Math / Algorithm Animation (Manim)

See absorbed skill `manim-video` (formerly `creative/manim-video`) for:
- Mathematical, scientific, and algorithmic visual explanations
- 3Blue1Brown-style production
- Cairo / manim engine render pipeline

## 5. ASCII Art & Video

See sibling skills `ascii-art` and `ascii-video` (under `creative/`) for:
- Pure Python ASCII art (pyfiglet, cowsay, image-to-ASCII)
- Converting video and audio to colored ASCII MP4 / GIF

## 6. Browser Creative Coding (p5js / pretext)

See absorbed skills `p5js` and `pretext` (under `creative/`) for:
- p5.js sketches: generative art, GLSL shaders, interactive / 3D
- Pretext demos: DOM-free text measurement/layout for typographic art,
  kinetic typography, ASCII obstacle art, text-as-geometry games

## 7. Songwriting & AI Music

See absorbed skill `songwriting-and-ai-music` (formerly `creative/songwriting-and-ai-music`) for:
- Lyric writing craft, phrasing, rhyme, and structure
- Prompt engineering for AI music generation (Suno, etc.)
- Tag taxonomy, narrative arc, genre conventions
