---
name: opencode
description: "Delegate coding to OpenCode CLI (features, PR review)."
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Coding-Agent, OpenCode, Autonomous, Refactoring, Code-Review]
    related_skills: [claude-code, codex, hermes-agent]
---

# OpenCode CLI

Use [OpenCode](https://opencode.ai) as an autonomous coding worker orchestrated by Hermes terminal/process tools. OpenCode is a provider-agnostic, open-source AI coding agent with a TUI and CLI.

## When to Use

- User explicitly asks to use OpenCode
- You want an external coding agent to implement/refactor/review code
- You need long-running coding sessions with progress checks
- You want parallel task execution in isolated workdirs/worktrees

## Prerequisites

- OpenCode installed: `npm i -g opencode-ai@latest` or `brew install anomalyco/tap/opencode`
- Auth configured: `opencode auth login` or set provider env vars (OPENROUTER_API_KEY, etc.)
- Verify: `opencode auth list` should show at least one provider
- Git repository for code tasks (recommended)
- `pty=true` for interactive TUI sessions

## Binary Resolution (Important)

Shell environments may resolve different OpenCode binaries. If behavior differs between your terminal and Hermes, check:

```
terminal(command="which -a opencode")
terminal(command="opencode --version")
```

If needed, pin an explicit binary path:

```
terminal(command="$HOME/.opencode/bin/opencode run '...'", workdir="~/project", pty=true)
```

## One-Shot Tasks

Use `opencode run` for bounded, non-interactive tasks:

```
terminal(command="opencode run 'Add retry logic to API calls and update tests'", workdir="~/project")
```

Attach context files with `-f`:

```
terminal(command="opencode run 'Review this config for security issues' -f config.yaml -f .env.example", workdir="~/project")
```

Show model thinking with `--thinking`:

```
terminal(command="opencode run 'Debug why tests fail in CI' --thinking", workdir="~/project")
```

Force a specific model:

```
terminal(command="opencode run 'Refactor auth module' --model openrouter/anthropic/claude-sonnet-4", workdir="~/project")
```

## Interactive Sessions (Background)

For iterative work requiring multiple exchanges, start the TUI in background:

```
terminal(command="opencode", workdir="~/project", background=true, pty=true)
# Returns session_id

# Send a prompt
process(action="submit", session_id="<id>", data="Implement OAuth refresh flow and add tests")

# Monitor progress
process(action="poll", session_id="<id>")
process(action="log", session_id="<id>")

# Send follow-up input
process(action="submit", session_id="<id>", data="Now add error handling for token expiry")

# Exit cleanly — Ctrl+C
process(action="write", session_id="<id>", data="\x03")
# Or just kill the process
process(action="kill", session_id="<id>")
```

**Important:** Do NOT use `/exit` — it is not a valid OpenCode command and will open an agent selector dialog instead. Use Ctrl+C (`\x03`) or `process(action="kill")` to exit.

### TUI Keybindings

| Key | Action |
|-----|--------|
| `Enter` | Submit message (press twice if needed) |
| `Tab` | Switch between agents (build/plan) |
| `Ctrl+P` | Open command palette |
| `Ctrl+X L` | Switch session |
| `Ctrl+X M` | Switch model |
| `Ctrl+X N` | New session |
| `Ctrl+X E` | Open editor |
| `Ctrl+C` | Exit OpenCode |

### Resuming Sessions

After exiting, OpenCode prints a session ID. Resume with:

```
terminal(command="opencode -c", workdir="~/project", background=true, pty=true)  # Continue last session
terminal(command="opencode -s ses_abc123", workdir="~/project", background=true, pty=true)  # Specific session
```

## Common Flags

| Flag | Use |
|------|-----|
| `run 'prompt'` | One-shot execution and exit |
| `--continue` / `-c` | Continue the last OpenCode session |
| `--session <id>` / `-s` | Continue a specific session |
| `--agent <name>` | Choose OpenCode agent (build or plan) |
| `--model provider/model` | Force specific model |
| `--format json` | Machine-readable output/events |
| `--file <path>` / `-f` | Attach file(s) to the message |
| `--thinking` | Show model thinking blocks |
| `--variant <level>` | Reasoning effort (high, max, minimal) |
| `--title <name>` | Name the session |
| `--attach <url>` | Connect to a running opencode server (e.g. `http://127.0.0.1:8901`) |
| `--port <N>` | Server mode: listen port (default: 0 = random) |
| `--hostname <host>` | Server mode: bind address (default: `127.0.0.1`) |

## Procedure

1. Verify tool readiness:
   - `terminal(command="opencode --version")`
   - `terminal(command="opencode auth list")`
2. For bounded tasks, use `opencode run '...'` (no pty needed).
3. For iterative tasks, start `opencode` with `background=true, pty=true`.
4. Monitor long tasks with `process(action="poll"|"log")`.
5. If OpenCode asks for input, respond via `process(action="submit", ...)`.
6. Exit with `process(action="write", data="\x03")` or `process(action="kill")`.
7. Summarize file changes, test results, and next steps back to user.

## PR Review Workflow

OpenCode has a built-in PR command:

```
terminal(command="opencode pr 42", workdir="~/project", pty=true)
```

Or review in a temporary clone for isolation:

```
terminal(command="REVIEW=$(mktemp -d) && git clone https://github.com/user/repo.git $REVIEW && cd $REVIEW && opencode run 'Review this PR vs main. Report bugs, security risks, test gaps, and style issues.' -f $(git diff origin/main --name-only | head -20 | tr '\n' ' ')", pty=true)
```

## Parallel Work Pattern

Use separate workdirs/worktrees to avoid collisions:

```
terminal(command="opencode run 'Fix issue #101 and commit'", workdir="/tmp/issue-101", background=true, pty=true)
terminal(command="opencode run 'Add parser regression tests and commit'", workdir="/tmp/issue-102", background=true, pty=true)
process(action="list")
```

## Session & Cost Management

List past sessions:

```
terminal(command="opencode session list")
```

Check token usage and costs:

```
terminal(command="opencode stats")
terminal(command="opencode stats --days 7 --models anthropic/claude-sonnet-4")
```

## Pitfalls

- Interactive `opencode` (TUI) sessions require `pty=true`. The `opencode run` command does NOT need pty.
- `/exit` is NOT a valid command — it opens an agent selector. Use Ctrl+C to exit the TUI.
- PATH mismatch can select the wrong OpenCode binary/model config.
- If OpenCode appears stuck, inspect logs before killing:
  - `process(action="log", session_id="<id>")`
- Avoid sharing one working directory across parallel OpenCode sessions.
- Enter may need to be pressed twice to submit in the TUI (once to finalize text, once to send).

## Three-Agent Architecture: Hermes + OpenCode + OpenClaw

### Architecture Overview

```
User
  ↓
Hermes-fn (主脑：plans, decomposes, aggregates, verifies)
  ├─ delegate_task → OpenCode (--attach tcp://localhost:8901)
  │   └─ Best for: Code development, refactoring, PR review, architecture design
  │
  └─ delegate_task → OpenClaw (agent --local OR ACP bridge)
      └─ Best for: Script execution, log analysis, batch ops, system surveys
```

### When to Use Which

| Scenario | Recommended Agent | Rationale |
|----------|------------------|-----------|
| Code refactoring, feature implementation | OpenCode | Interactive, stateful, supports multi-turn editing |
| PR review, code audit | OpenCode | Built-in `pr` command, code-native |
| Log analysis, batch processing | OpenClaw (`agent --local`) | Fast, stateless, JSON output |
| System surveys, service initialization | OpenClaw (`agent --local`) | Command-heavy, output capture |
| Multi-turn Agent collaboration | OpenClaw + ACP → Hermes | Full Hermes toolset, memory, skills |
| Complex orchestration (install + configure + verify) | Hermes-fn → OpenClaw | Separation of concerns, error resilience |

### OpenCode vs OpenClaw: Detailed Comparison

| Aspect | OpenCode | OpenClaw |
|--------|----------|----------|
| **Connection** | TCP server (`--attach http://127.0.0.1:8901`) | CLI (`agent --local`) or ACP bridge |
| **Session** | Stateful (long-lived) | Stateless (`--local`) or stateful (ACP) |
| **Model** | Configurable (any provider) | Embedded (`agnes-2.0-flash`) |
| **Output** | Text/markdown (TTY) | JSON (`payloads[0].text`) |
| **Startup** | ~2s (server already running) | ~3-5s (local agent init) |
| **Best for** | Code collaboration | Script execution |
| **Hermes pattern** | `opencode --attach <url> run` | `openclaw agent --local --json` |

### Comparison with Hermes ACP Bridge

For **OpenClaw ↔ Hermes** ACP collaboration (OpenClaw as client, Hermes as server), see `skill_view(name="openclaw", file_path="references/acp-bridge.md")`.

**Note**: OpenCode does NOT have native ACP bridge support yet. OpenCode uses `--attach` (HTTP) for client-server, while OpenClaw supports stdio ACP.

## Verification

Smoke test:

```
terminal(command="opencode run 'Respond with exactly: OPENCODE_SMOKE_OK'")
```

Success criteria:
- Output includes `OPENCODE_SMOKE_OK`
- Command exits without provider/model errors
- For code tasks: expected files changed and tests pass

## Rules

1. Prefer `opencode run` for one-shot automation — it's simpler and doesn't need pty.
2. Use interactive background mode only when iteration is needed.
3. Always scope OpenCode sessions to a single repo/workdir.
4. For long tasks, provide progress updates from `process` logs.
5. Report concrete outcomes (files changed, tests, remaining risks).
6. Exit interactive sessions with Ctrl+C or kill, never `/exit`.

## Server Mode (Persistent Collaboration)

For stable multi-session collaboration, run OpenCode as a systemd-managed headless server:

### Systemd Service Setup

```ini
# /etc/systemd/system/opencode-collab.service
[Unit]
Description=OpenCode Local Collaboration Service
After=network.target

[Service]
Type=simple
User=lan
WorkingDirectory=/home/lan
ExecStart=/home/lan/.opencode/bin/opencode serve --port 8901 --hostname 127.0.0.1
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
Environment="HOME=/home/lan"

[Install]
WantedBy=multi-user.target
```

### Enable and Verify

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now opencode-collab
systemctl status opencode-collab
ss -tuln | grep 8901
```

### Connect to Server

```bash
# Hermes or any client can attach:
opencode --attach http://127.0.0.1:8901 run "<task>"

# Interactive session:
opencode --attach http://127.0.0.1:8901
```

### Benefits

- **Persistence**: Survives shell exits, SSH disconnects
- **Stability**: Auto-restart on crash (`Restart=always`)
- **Low latency**: Local Unix loopback (no network overhead)
- **Session continuity**: Multiple clients can attach to same server
- **Security**: Bound to `127.0.0.1`, no external exposure

### Troubleshooting

- Server fails to start: check `journalctl -u opencode-collab --no-pager -n 30`
- Port not listening: verify `ExecStart` uses correct binary path (`~/.opencode/bin/opencode`)
- Connection refused: ensure service is `active (running)` and port is bound

### Pitfalls Discovered (2026-06-24)

- **`--cwd` parameter causes startup failure**: Do NOT add `--cwd /home/lan` to `ExecStart`. The server ignores it and exits with status 1.
- **`SupplementaryGroups` syntax incompatible**: Ubuntu 26.04 systemd does not support `SupplementaryGroups=docker` in service files. Instead, ensure the user is in the docker group (`usermod -aG docker lan`) and commands use `sudo` when needed.
- **File write permissions**: OpenCode server cannot write to `/tmp/` or `/proc/` from sandboxed sessions. Restrict file operations to `/home/lan/` or user-owned directories.
- **Docker socket permission**: Even with user in docker group, OpenCode subprocess may not inherit group membership. Use `sudo docker` explicitly in prompts.

## Hermes主脑调度模式 (Hermes-fn Orchestrator Pattern)

For complex multi-step tasks (system surveys, dependency initialization, batch operations), use Hermes-fn as orchestrator with OpenCode as execution worker:

### Architecture

```
User Request
    ↓
Hermes-fn (plans, decomposes, aggregates)
    ↓
opencode --attach http://127.0.0.1:8901 run "<task>"
    ↓
OpenCode (executes commands, captures output)
    ↓
Hermes-fn (reads output, formats report, verifies)
```

### When to Use This Pattern

- System-wide surveys (hardware, services, dependencies)
- Multi-service initialization (install + configure + verify)
- Long-running batch operations with progress tracking
- Tasks requiring command output capture and analysis

### Example: System Survey Delegation

```bash
# Hermes-fn writes plan first
write_file(path="/tmp/system-survey-plan.md", content="...")

# Delegates to OpenCode
opencode --attach http://127.0.0.1:8901 run "
调查本机系统配置和硬件资源。执行以下命令并整理结果：

1. 系统信息：uname -a, hostnamectl, cat /etc/os-release
2. 用户与权限：whoami, id, sudo -n whoami, groups
3. CPU: lscpu | grep -E 'Model name|CPU\\(s\\)|Thread|Core'
4. 内存：free -h
5. 磁盘：df -hT | grep -v tmpfs, lsblk
6. 网络：ip -br addr show, ip route | grep default
7. GPU: lspci | grep -i vga

将结果整理为 Markdown 格式，保存为 /tmp/system-info.md。
"

# Hermes-fn reads and aggregates output
read_file(path="/tmp/system-info.md")
```

### Example: Service Initialization Delegation

```bash
opencode --attach http://127.0.0.1:8901 run "
执行系统优化任务：安装并初始化 Node.js、Docker、Redis。

**Task 1: Node.js LTS**
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs
node --version && npm --version

**Task 2: Docker**
sudo apt-get install -y docker.io docker-compose-v2
sudo usermod -aG docker lan
sudo systemctl enable --now docker
sudo docker run --rm hello-world

**Task 3: Redis**
sudo apt-get install -y redis-server
sudo systemctl enable --now redis-server
redis-cli ping

将所有命令输出保存为 /tmp/install-log.md，标注成功 [✅] 或失败 [❌]。
"
```

### Key Advantages

1. **Separation of concerns**: Hermes plans, OpenCode executes
2. **Output capture**: OpenCode writes logs to files, Hermes reads and formats
3. **Error resilience**: If OpenCode fails mid-task, logs are preserved
4. **Parallel capability**: Multiple OpenCode instances can run in parallel with different workdirs

### Pitfalls

- **Permission prompts**: OpenCode may request permission for sensitive operations (sudo, file writes). User must approve.
- **File write permissions**: OpenCode may not be able to write to arbitrary paths. Use `/tmp/` or user-owned directories.
- **Unicode confusables**: Security scanner may flag OpenCode output containing Unicode lookalikes. User approval required.
- **Timeout limits**: Use `timeout <N>` wrapper for long tasks (e.g., `timeout 180 opencode ...`).
- **Output truncation**: Large command outputs may be truncated. Instruct OpenCode to save to file instead of printing.
