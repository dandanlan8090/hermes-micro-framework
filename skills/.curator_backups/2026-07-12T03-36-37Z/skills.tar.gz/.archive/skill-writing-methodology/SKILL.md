---
name: skill-writing-methodology
description: "Skill 写作方法论 — leading word、progressive disclosure、failure modes、description 三段式。使用场景：写新 skill/重写现有 skill/审查 skill 质量/skill 盲测评估。禁用：仅改 frontmatter 字段/纯文档修改。"
version: 1.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags:
      trigger:
        - "写 skill"
        - "skill 质量"
        - "leading word"
        - "skill 方法论"
        - "failure mode"
        - "skill 审查"
        - "盲测"
        - "write skill"
        - "skill writing"
        - "skill methodology"
        - "如何写 SKILL"
      disable:
        - "读 skill"
        - "仅改 frontmatter"
        - "删除 skill"
    skill_type: "methodology"
    priority: "high"
    next_skill: "new-skill-template"
prerequisites:
  commands: []
---

# Skill 写作方法论

Skill 写作的 craft 部分 — 不关心 frontmatter 字段名，关心**怎么写出来好用的 skill**。
与 `hermes-agent-skill-authoring`（in-repo 技能的机械流程）和 `NEW_SKILL_TEMPLATE.md`（frontmatter schema）互补。

---

## 第一性原理

1. **skill 不是文档，是压缩的操作记忆。** 它改变 agent 的行为。每一行如果不改变行为就删掉。
2. **改进优先于新增。** 在写新 skill 前，先问："这个教训能否加入现有 skill 的失败模式段/规则段/工作流？" 如果能，就改旧不建新。新建 skill 稀释了整个库的价值（召回噪音 + 维护面）。只有证明现有结构无法承载时才允许新 skill。这条对齐 SOUL.md §8。
3. **description 是唯一始终加载的字段。** description 写不好，skill 在 vdb 中被低分召回或在 LLM 触发决策中被跳过。
4. **leading word 比多句话有效。** 一个模型召回区内的强概念词（"root cause"、"dispatch"、"gate"）抵 10 句解释。
5. **失败模式比成功案例更有教学价值。** 告诉 agent "什么情况会出错" 让它学会识别并及时止损。
6. **渐进披露。** SKILL.md 只放必须始终可见的内容，分支/例子/长 schema 推 references/、scripts/、templates/。

---

## 工作流

### 0. 改进优先于新增（Step 0）

在动手写任何新 skill 前，先审计现有 skill 目录：

```bash
# 查当前 skill 类别
ls ~/.hermes/skills/software-development/
```

对每个可能有重叠的 skill 问三个问题：
1. 这个教训能否作为一条**新的 failure mode** 加入现有技能？
2. 能否作为**一个子步骤 / pitfall** 加入现有技能的工作流？
3. 能否作为 **references/ 文件** 加入现有技能的目录？

只有当三个答案都是"否"时才新建。并在 commit/总结中写"现有 XXX 无法承载因为 YYY"。

### 2. 确定 class-level 定位

自问：这是方法论、工作流、工具指南、还是集成？
- 方法论（methodology）— 定义"如何做"，如 TDD、调试、本文
- 工作流（workflow）— 定义环节顺序，如 plan、oracle mode
- 工具（tool）— 特定 CLI 使用指南，如 github、blogwatcher
- 集成（integration）— 外部 API 对接，如 notion、airtable

### 2. 选 leading word

从 NEW_SKILL_TEMPLATE.md §Leading Word 词汇库挑一个。没有合适的可以自定义，但必须在 SOUL.md 中注册为已知词才能拿到 vdb 2x boost。

### 3. 写 description 三段式

```
前 30 字符：{leading word} + 触发场景条件
中间 60 字符：核心动作 + 产出
末尾：分支条件（"Use when X / Use when Y"）+ 禁用场景（"禁用：Z"）
```

示例：
```
description: "Root-Cause：交互式调试与根因排查。Use when 报错/异常/traceback/服务不可用。禁用：纯配置变更/仅查看日志"
```

### 4. 组织 SKILL.md 四段式

```
# 标题 (leading word)

## 第一性原理 (First Principles)
3-5 条，每条一行：定义 + 为什么重要 + 怎么识别违反

## 工作流 (Workflow)
编号步骤，每步一个 completion criterion（可验证）
每步结束问：agent 怎么知道这步做完了？

## 规则 (Rules)
- 约束条件
- 禁用场景
- 常用命令模板

## 失败模式 (Failure Modes)
每个一行：tell（怎么识别）+ fix（怎么修）
```

### 5. 追加失败模式段

从 9 个标准模式中挑出当前 skill 最常见的 2-3 个：

| 模式 | tell（怎么识别） | fix（怎么修） |
|------|-----------------|-------------|
| <b>Premature Completion</b> | agent 在一个消息里完成了多个步骤；跳过命令直接说结果 | 加固 completion criterion；分割步骤到独立文件 |
| <b>Embargo</b> | agent 发现了重要信息但没有在恰当的时机披露（按步骤憋着不说） | 加 escape valve："顺序决定展示，不决定披露" |
| <b>Lucky Pass</b> | 验证通过只因世界或用户恰好在正确时间输入了关键信息 | 把 eliciting probe 编码为显式步骤 |
| <b>Duplication</b> | 同一含义出现在两处 | 合并到一个 source of truth |
| <b>Sediment</b> | 旧规则积累，新加不删旧 | 加新规则时找旧等价规则删除 |
| <b>War Story</b> | 例子写的是"我们当时改了 X 和 Y 参数"——函数名/值/某次修复的流水账 | 删具体值，只写 smell（怎么识别）+ signal（怎么确认） |
| <b>Implementation Index</b> | skill 指着今天源码的特定行号/函数名 | 删行号，让 agent grep 找当前 owner |
| <b>Sprawl</b> | SKILL.md 超过 100 行（不含 frontmatter） | 推 references/ scripts/ templates/ |
| <b>No-op</b> | "be thorough" / "be careful" / "使用最佳实践" 这种模型默认就在做的 | 全句删 |

### 6. 写例子（教问题不教答案）

✅ smell + signal + 让 agent 自己推
❌ "我们改了什么" — war story，几个月就腐烂

✅ 正确示例：
```
问题：一个方向性判断门控在中心距离上，从任何方向读都是错的。
tell：无论从哪个方向接近目标，门控决策一样。
fix：改成角度锥形门控（APEX_ARC），每个方向独立计算。
```

❌ 错误示例：
```
问题：中心距读错了。
我们改成 keyed on FRONT_ARC 就修好了。
```

### 7. 指向验证工具

新 skill 创建后，用 `eval_skill.py` 做盲测：
```bash
cd ~/.hermes/vdb && source .venv/bin/activate && \
python3 eval_skill.py --skill <name> --case 1 --prompt blind
```

把生成的 prompt 喂给一个 fresh Hermes 会话，拿 artifact 回来再用 judge prompt 判 verdict。

---

## 规则

### Description 规则

- 必含 leading word，前 30 字符
- 禁用场景写在最后（不重复 frontmatter tags.disable 的全部，只写最重要的 1-2 个）
- ≤ 200 字符（vdb 检索和 LLM 触发决策的 context 成本决定）

### SKILL.md 规则

- ≤ 100 行（不含 frontmatter）
- 超出推 references/（例子/schema/变体）、scripts/（可重跑脚本）、templates/（样板文件）
- references/ 单文件 ≤ 200 行
- 通用术语引用 SOUL.md 或 AGENTS.md 不重写定义

### 引用规则

- leading word 词汇库：`NEW_SKILL_TEMPLATE.md §Leading Word 词汇库`
- frontmatter 字段：`NEW_SKILL_TEMPLATE.md §Frontmatter 必填字段`
- description 检查清单：`NEW_SKILL_TEMPLATE.md §新增技能检查清单`
- "改进优先于新增"：SOUL.md §8
- 盲测工具：`~/.hermes/vdb/eval_skill.py`

### 红线

- **不要为了"显得高级"硬塞 leading word**。no-op leading word 比重写还糟。
- **不要写 war story**。教 agent 识别问题，不是教它背答案。
- **不要 sedment**。加新规则前找旧等价规则删掉。
- **不要让 skill 超过 100 行不推 references/**。sprawl 是质量下降的最早信号。

---

## 失败模式

本 skill 最实用的部分是 failure modes 表。在写任何新 skill 时，对照 9 个模式审查初稿：
1. 有没有 premature completion 风险？（steps 跳步）
2. 例子是 war story 还是 teach signal？
3. 有没有 implementation index？（行号/函数名）
4. 有没有 sprawl？（>100 行）
5. 有没有 no-op？（"be thorough" 类）
6. description 有 leading word 吗？
7. 有 failure modes 段吗？
8. 有配套的 eval cases 吗？
9. 是否遵循"改进优先于新增"？（SOUL.md §8）

---

## 验证清单

- [ ] leading word 已选且在前 30 字符
- [ ] description 三段式（leading + 动作 + 分支）
- [ ] SKILL.md ≤ 100 行
- [ ] 四段结构（First Principles + Workflow + Rules + Failure Modes）
- [ ] 每个步骤有 completion criterion
- [ ] 例子写 smell 不写 patch
- [ ] 无 war story / implementation index / no-op
- [ ] 引用 NEW_SKILL_TEMPLATE.md 做 frontmatter
- [ ] 引用 SOUL.md §8 做"改进优先"检查
- [ ] eval 盲测 prompt 已生成
- [ ] 重新跑 vdb 索引确认召回正常（build_index(force=True)）
