---
name: hermes-config-repo
description: Hermes 配置发布到 GitHub Repo — 将 SOUL.md/AGENTS.md/USER.md 及关联技能打包发布为公开仓库。触发：整理
  Hermes 配置/发布到 GitHub/做 repo/脱敏发布。
version: 1.0.0
author: Hermes-fn
license: MIT
platforms:
- linux
- macos
- windows
metadata:
  hermes:
    tags:
      trigger:
      - 整理 hermes 配置
      - 发布到 github
      - 做成 repo
      - hermes 配置发布
      - 配置脱敏
      - hermes base config
      - hermes 模板
      disable:
      - 私人定制
      - 不需要发布
      - 单次任务
    skill_type: workflow
    priority: normal
    related_skills:
    - hermes-agent
    - github
prerequisites:
  commands:
  - gh
---
# Hermes Config Repo Publishing（配置发布到 GitHub）

## 概述

将 Hermes 配置文件（SOUL.md / AGENTS.md / USER.md）及关联技能打包成公开 GitHub 仓库的标准工作流。核心挑战是**脱敏**（私人信息移除）和**技能关联**（发现并打包被引用的 skill）。

---

## 标准工作流（七步）

### Step 1: 读取源文件

必须读取的四个文件（严格按此顺序，硬编码路径）：
```
~/.hermes/SOUL.md
~/.hermes/memories/USER.md      # 注意：实际文件名是 USER.md，不是 USER.md.md
~/.hermes/memories/MEMORY.md
~/.hermes/AGENTS.md
```

**注意**：实际文件名是 `~/.hermes/memories/USER.md`（不是 `.md.md` 后缀）。SOUL.md 中写的 `USER.md.md` 是文档描述错误，源文件实际无重复 `.md`。

### Step 2: 创建 GitHub Repo

```bash
gh repo create <repo-name> --public --description "描述" --clone=false
```

### Step 3: 本地初始化并关联远端

```bash
mkdir -p /tmp/<repo-name> && cd /tmp/<repo-name> && git init
git remote add origin https://github.com/<owner>/<repo-name>.git
```

### Step 4: 脱敏处理（核心）

必须脱敏的内容：

| 敏感类型 | 处理方式 |
|---------|---------|
| GitHub PAT / token | 完全移除，用 `gh auth token` 获取推送凭证 |
| 个人信息（B站账号/GitHub用户名/粉丝数等） | 删除或转为模板占位符 |
| 主机名/系统路径/具体设备描述 | 通用化 |
| 密码/key/secret | 模板化（`YOUR_API_KEY` 占位） |

**MEMORY.md 策略**：
- 默认不发布（几乎必然包含个人信息）
- 若确实需要，从中选择性提取通用内容
- USER.md 转为**模板**（用户画像占位符），不包含真实信息

**源文件 vs 模板文件**：
```
SOUL.md       → 直接发布（通用规则，无个人信息）
AGENTS.md     → 直接发布（方法论，无个人信息）
USER.md       → 转为模板（USER.md.template），真实配置放 ~/.hermes/memories/USER.md
MEMORY.md     → 不发布
skills/       → 挑选关联 skill，逐一脱敏后发布
```

### Step 5: 发现并打包关联技能

从 SOUL.md / AGENTS.md 的正文中 grep 扫描所有被引用的 skill 名称：

```bash
# 在 skills 目录扫描所有 SKILL.md 中的 skill 引用
grep -rh "skill_view\|skill:" ~/.hermes/skills --include="SKILL.md" | \
  grep -oE "name: [a-z0-9-]+" | sort -u

# 或者直接看 frontmatter 的 related_skills 字段
grep -rh "related_skills:" ~/.hermes/skills --include="SKILL.md"
```

**必须打包的 skill 类型**：
1. SOUL.md / AGENTS.md 正文明确引用的（如 `hermes-oracle-mode`、`new-skill-template`）
2. `related_skills` 中声明的依赖
3. 用户在对话中明确要求的（如 `NEW_SKILL_TEMPLATE.md`）

**技能脱敏原则**：
- 移除作者名（用 `Hermes Agent`）
- 移除具体文件路径/主机名（如 `/home/lan/` → `/home/user/`）
- 移除 token/账号/密钥描述
- 移除版本回执（如 "2026-06-23 修复半配置时实施"）
- 保留 frontmatter、核心流程、触发规则

### Step 6: 写文件并 commit

```bash
cd /tmp/<repo-name>
# 写所有文件...
git add -A
git commit -m "Initial commit: ..."
```

### Step 7: 推送（Token 安全处理）

**直接方式（有 gh auth）**：
```bash
git push -u origin main
```

**手动注 token 方式**（需清理）：
```bash
# 临时注入 token
git remote set-url origin https://$(gh auth token)@github.com/<owner>/<repo-name>.git
git push -u origin main
# 推送后立即还原为无 token 的 URL
git remote set-url origin https://github.com/<owner>/<repo-name>.git
```

**禁止**：将 token 写入配置文件或 commit 到 git。

---

## Skill 文件夹结构建议

```
skills/
├── new-skill-template/              # 技能开发模板（必须）
├── plan/                            # Plan Mode（AGENTS.md §2 强依赖）
├── source-driven-development/       # 源码驱动（SOUL.md 引用）
├── hermes-oracle-mode/              # 主脑模式（SOUL.md 触发规则引用）
├── hermes-shipping-verification/    # 发布验证（AGENTS.md §1 引用）
├── hermes-agent/                    # Hermes 配置指南
├── codebase-memory-first/           # 代码库图谱钩子（AGENTS.md §2.0 引用）
├── doubt-driven-development/         # 怀疑驱动（AGENTS.md §1 引用）
└── ai-conv-style-discipline/         # 对话风格（交互偏好相关）
```

---

## 参考：脱敏 checklist

**SOUL.md / AGENTS.md**：通常可直接发布（规则文件，无个人信息）

**USER.md（模板化）**：
- [ ] 用户名 → 占位符
- [ ] 真实硬件/主机描述 → 通用描述
- [ ] 账号/平台信息 → 删除
- [ ] Agent 协议偏好 → 保留（通用描述）

**技能文件**：
- [ ] 作者名 → `Hermes Agent` 或 `Community`
- [ ] 具体路径 `/home/lan/` → `/home/user/` 或 `~/.hermes/`
- [ ] 版本回执 / 时间戳 → 移除
- [ ] token / key / secret → `YOUR_API_KEY` 占位
- [ ] personal info (mid, uid, token scopes) → 完全移除
- [ ] 保留：frontmatter、核心流程、触发规则、验证 checklist

**不发布的文件**：
- MEMORY.md（强制不发布）
- credentials / tokens
- project-specific configs

---

## 输出交付

完成时应交付：
1. GitHub repo URL
2. 目录结构说明
3. 快速开始命令
4. 文件说明表格

---

**最后更新**: 2026-07-09
**创建原因**: 用户要求整理 Hermes 配置发布到 GitHub，发现需要标准化脱敏流程和技能发现逻辑。