#!/usr/bin/env bash
# host-introspect.sh — single-pass host probe for Hermes Agent runtime
# Emits four blocks: hardware / system / dependencies / services-ports
# Designed to be sourceable (so caller can capture variables) OR piped to clipboard.
#
# Usage:
#   bash host-introspect.sh                # human-readable
#   bash host-introspect.sh --json out.json
#
# This is the canonical "what does this box look like" probe. Drop it in any
# ~/.hermes/skills/hermes-bootstrap/scripts/ and source from session bootstrap.

set -u
separator() { printf '\n=== %s ===\n' "$1"; }

separator "1. Hermes Agent"
which hermes 2>/dev/null
hermes --version 2>/dev/null | head -3
hermes config path 2>/dev/null

separator "2. Host hardware"
uname -a
lscpu 2>/dev/null | grep -E "Model name|CPU\(s\)|Architecture|Vendor"
free -h | head -3
lsblk -o NAME,SIZE,MODEL,TYPE 2>/dev/null | head -8

separator "3. System"
cat /etc/os-release 2>/dev/null | grep -E "PRETTY|NAME|VERSION"
uptime
cat /proc/loadavg
hostname -I
ip route 2>/dev/null | grep default | head -1

separator "4. Dependencies"
for t in docker python3 git curl ssh rsync jq nvidia-smi ollama; do
  printf '%-12s ' "$t"
  if command -v "$t" >/dev/null 2>&1; then
    "$t" --version 2>&1 | head -1
  else
    echo "(missing)"
  fi
done

separator "5. Services & ports"
if command -v systemctl >/dev/null; then
  systemctl list-units --type=service --state=running --no-pager 2>/dev/null \
    | grep -vE '^UNIT |^Legend:' | head -8
fi
(command -v ss >/dev/null && ss -tlnp 2>/dev/null) \
  || netstat -tlnp 2>/dev/null \
  || echo "(no ss/netstat)"

separator "6. GPU"
if command -v nvidia-smi >/dev/null; then
  nvidia-smi --query-gpu=name,memory.total,temperature.gpu --format=csv 2>/dev/null
else
  echo "(no NVIDIA GPU or driver not installed)"
fi
