# Host profile snapshot — 2026-06-22

Captured during the inaugural bootstrap session for user `lan` on host `fnubuntu`.
Use as baseline for drift detection.

## Identity
- Hostname: fnubuntu
- User: lan (uid 1000, sudo with NOPASSWD ALL)
- Timezone: (server-local — not pinned in config; recommend Asia/Shanghai)
- Working dir: /home/lan

## Hardware
- CPU: Intel Core Ultra 5 125H · 10 cores (GenuineIntel x86_64)
- RAM: 5.3 GiB DDR (used 697M, avail 4.6G at session start)
- Swap: 4.0 GiB
- Disk: 64 GB QEMU virtual disk → 49 GB LVM `/dev/mapper/ubuntu--vg-ubuntu--lv`, 22% used
- GPU: none (no NVIDIA, no driver)

## System
- Distro: Ubuntu 26.04 LTS (Resolute Raccoon) — pre-release-grade
- Kernel: 7.0.0-22-generic x86_64
- Uptime: 57 min at capture (load 0.07 0.09 0.09 — idle)
- Network: enp4s0 → DHCP 192.168.33.113 / gw 192.168.33.1
- IPv6: fd00:80ae:54b8:235c::1006 reachable

## Hermes
- Version: v0.17.0 (2026.6.19) upstream 5ff11a68
- Active profile: default
- Project root: /home/lan/.hermes/hermes-agent
- Model: minimaxai/minimax-m3 (provider nvidia, base_url integrate.api.nvidia.com/v1)
- Persona: none (raw Hermes-fn)
- Loaded modules: SOUL → USER → MEMORY → AGENTS → config.yaml
- Skills library: explicit read-only this session (no in-flight skill edits)

## Dependencies in PATH
- ✅ git 2.53, curl 8.18, rsync 3.4.1, jq 1.8.1, openssh-server (sshd running)
- ⚠ python3 3.14.4 (no `pip` module — PEP 668 forces venv/uv)
- ❌ docker (not installed)
- ❌ ollama
- ❌ NVIDIA driver
- ❌ uv/pipx (use venv or install uv first)

## Open ports / services
- 22/tcp  sshd    systemd unit active
- 53/tcp  systemd-resolved (loopback + private NIC)
- crond  active (user crontab empty)
- 80/443/8080 NOT listening → no public services yet

## Adjacent hardware (off-host)
- 老黎 main rig: S905L3 电视盒子 cm211 (Armbian) — SSH required to enroll as dispatch node
  Keep this entry; cross-host SSH config lives in ~/.ssh/config with profile-keyed aliases.

## Bootstrap deltas applied this session
1. 46 × `hermes config set` to push toward max-autonomy (see SKILL.md Step A)
2. user-side sudoers drop: `/etc/sudoers.d/99-lan-nopasswd` (NOPASSWD: ALL)
3. Verified: `sudo -n whoami` ⇒ root
4. Browser config: `allow_private_urls=true`, `record_sessions=true`

## Risks / follow-ups
- No GPU → local LLM / Stable Diffusion / ComfyUI not viable on this host
- Pre-release OS (26.04) — kernel 7.0.0 is unusual; snapshot before `apt upgrade` storms
- No `pip` → venv workflow required for any Python module install
- No backups configured
