---
name: visual-design
description: 'Create artifacts and designs: diagrams, hand-drawn Excalidraw JSON,
  SVG architecture diagrams, infographics, HTML landing pages from real design systems,
  DESIGN.md token specs, kinetic typography, and browser creative-coding demos — class-level
  guidance from brief to delivered artifact.'
version: 1.0.0
author: Hermes Agent (umbrella consolidation)
license: MIT
metadata:
  hermes:
    tags:
      trigger:
      - 设计
      - 可视化
      - 图表
      - 原型图
      - UI设计
      disable:
      - creative_gen
      - read_only
    related_skills:
    - excalidraw-digests
    - architecture-diagram-digests
    - design-md
    - popular-web-designs
---
# Visual Design — Class-Level Guidance

This umbrella covers the full lifecycle from a design brief to a delivered visual
artifact — diagrams, technical infographics, HTML pages from real design systems,
DESIGN.md token specs, and browser-based creative coding / kinetic typography.

## Subsection Map

| What you need to do | Go to |
|---|---|
| Draw hand-drawn style architecture / flow / sequence diagrams | [Excalidraw JSON Diagrams](#1-excalidraw-json-diagrams) |
| Generate dark-themed SVG architecture / cloud / infra diagrams | [SVG Architecture Diagrams](#2-svg-architecture-diagrams) |
| Create info-graphic layouts (21 layouts × 21 styles) | [Info-Graphics (Baoyu)](#3-info-graphics-baoyu) |
| Produce a polished one-off HTML page / prototype / deck | [One-Off HTML / Prototype (Claude Design)](#4-one-off-html--prototype-claude-design) |
| Author a formal DESIGN.md token spec file (and export) | [DESIGN.md Token Spec](#5-designmd-token-spec) |
| Build kinetic typography and text-flow browser demos | [Kinetic Typography & Text-Art Demos](#6-kinetic-typography--text-art-demos-pretext) |
| Render HTML/CSS from a real-world design system | [Design System Templates (54 brands)](popular-web-designs) |

Notes:
- `[popular-web-designs]` is retained as a standalone skill — its 54-token catalog
  is the deliverable; use its subsection map there for brand-by-brand lookup.

## 1. Excalidraw JSON Diagrams

See absorbed skill `excalidraw` (now in `.archive`) for:
- Writing Excalidraw element JSON directly
- Container-binding (shape + text) and arrow bindings
- Color palette, font sizing, drawing order, and element sizing guidelines
- Uploading `.excalidraw` files for shareable links

## 2. SVG Architecture Diagrams

See absorbed skill `architecture-diagram` (now in `.archive`) for:
- Dark-themed technical architecture HTML/SVG diagrams (cloud, infra, microservices)
- Component rendering, semantic color palette, connection rules, and z-order
- HTML template reference for one-file output

## 3. Info-Graphics (Baoyu)

See absorbed skill `baoyu-infographic` (now in `.archive`) for:
- 21 layouts × 21 visual styles for infographic production in Chinese
- Poster, explainer, report-card, and comparison infographic patterns

## 4. One-Off HTML / Prototype (Claude Design)

See absorbed skill `claude-design` (now in `.archive`) for:
- Design brief → variant generation → local HTML verification
- Taste-first prompt engineering and anti-slop prompts
- Verifying HTML/CSS with browser vision

## 5. DESIGN.md Token Spec

All DESIGN.md content is re-homed into this umbrella.

- **Starter template**: `templates/design-md/starter.md` (canonical DESIGN.md skeleton with YAML token front matter + markdown body sections).
- **Authoring**: One file combines machine-readable design tokens (YAML front matter) + human-readable rationale (markdown body, canonical sections).
- **CLI** (`npx @google/design.md`): `lint` (structure + WCAG contrast), `diff` (version regressions), `export` (Tailwind or W3C DTCG JSON).
- **Token types & section order**: token groups (color, typography, spacing, radius, shadow), canonical section order, component property whitelist per Google's spec (`google-labs-code/design.md`, Apache-2.0).

## 6. Kinetic Typography & Text-Art Demos (Pretext)

See absorbed skill `pretext` (now in `.archive`) for:
- DOM-free multiline text measurement & layout (15KB, no dependencies)
- Reflow around obstacles, text-as-geometry games, kinetic typography
- Performance notes, demo recipes, and community corpus links
- Uses `@chenglou/pretext` via `esm.sh` CDN in single-file HTML demos

## Boundary: This Umbrella vs Adjacent Skills

- For **normal photo-real / AI-generated images**, use **Generative Image / 3D (ComfyUI)**
  under `media/media-creation-and-audio/`.
- For **real-time audio-reactive motion graphics**, use `touchdesigner-mcp` under
  `creative/` (retained standalone; gap between generative media and inline 
  creative coding that future curator pass could revisit).
- For **pure generative Canvas / WebGL art with no text layer**, `p5js` under
  `creative/` (retained standalone; close enough to pretext/ASCII that a future
  pass could fold it in — status: "slipped net".
- For **generative image / 3D / video** needs go to the `media-media-creation-and-audio umbrella.
- The yard closer to text/typography/ASCII sketching live here as visual-design.
- The ones with a dedicated tool ecosystem stay standalone without shoehorning them into an umbrella they don't really belong.
