---
name: debugging-patterns
description: Interactive code debugging patterns — Python (pdb/debugpy) and Node.js
  (inspect/CDP). Class-level guidance for choosing, setting up, and effective breakpoint-driven
  debugging across both ecosystems.
version: 1.0.0
author: Hermes Agent (CURATOR umbrella consolidation)
license: MIT
platforms:
- linux
- macos
- windows
metadata:
  hermes:
    tags:
      trigger:
      - 调试
      - debug
      - python调试
      - 错误排查
      - pdb
      disable:
      - code_development
      - read_only
    related_skills:
    - node-inspect-debugger
    - python-debugpy
---
# Debugging Patterns — Class-Level Guidance

> **What this skill covers:** A unified entry point for interactive breakpoint-driven
> debugging of running Python or Node.js code. It does not cover log-line debugging
> (use `logging.debug` / `console.log` instead) or test-driven debugging (use
> `pytest -vv --tb=long --showlocals` first).
>
> Pick your ecosystem below, or read the [Decision Guide](#decision-guide) if
> you're unsure which tool to reach for.

## Decision Guide

| Situation | Recommended Tool | Why |
|-----------|-----------------|-----|
| A Python test fails and the traceback doesn't reveal why | `python-debugpy` (breakpoint mode) | Fastest introspection into live Python state |
| A long-running Python process misbehaves (gateway, subprocess, daemon) | `python-debugpy` (remote-attach mode) | Can attach to an already-running PID without restart |
| A Node test or Ink/TUI component crashes | `node-inspect-debugger` (`node inspect`) | Built-in, zero-install, REPL is fast |
| A TUI gateway or `_SlashWorker` subprocess misbehaves | Depends on language: **Python** → debugpy, **Node** → node-inspect | Match the runtime |
| Post-mortem: an exception fired in production-ish code | Either — `pdb.post_mortem()` (Python) or `node inspect` on dump | Both ecosystems equally capable |
| Debugging inside a subprocess / child process | Language of the child process | pdb does not follow forks; debugpy needs the target's PID |
| Want a heap snapshot or CPU profile | `node-inspect-debugger` (CDP → HeapProfiler/Profiler) | Chrome DevTools Protocol offers this out of the box |

## Choosing Between Python and Node

- If you can add a `breakpoint()` line, **Python wins** — simplest workflow.
- If you need to attach to a process that cannot be restarted, use **debugpy** (Python) or **SIGUSR1 + node inspect -p** (Node). Both are zero-restart.
- If you want to automate breakpoints across many runs or collect state non-interactively, use **CDP via `chrome-remote-interface`** (Node) or **debugpy + DAP client** (Python). Both are scriptable, but Node's CDP tooling is slightly more ergonomic for agents.
- If you need scope inspection in a closure or async handler — both work; use whichever runtime you're in.

## Python Debugging — Quick Start

See `references/python-debugging.md` for the full reference:
- Three tools: `breakpoint()` + pdb, `python -m pdb`, and debugpy (remote/DAP)
- Post-mortem on any exception
- Attaching to running Hermes processes (gateway, tui_gateway, `_SlashWorker`)
- pytest integration (with xdist pitfall covered)
- Common pitfalls: PYTHONBREAKPOINT=0, ptrace_scope, asyncio limitations

**Minimal recipe:**

```python
def compute(x, y):
    result = some_helper(x)
    breakpoint()          # drops into pdb here
    return result + y
```

Run normally; you land at the breakpoint line with full locals access.

## Node.js Debugging — Quick Start

See `references/node-debugging.md` for the full reference:
- `node inspect` REPL (built-in, zero install)
- CDP via `chrome-remote-interface` (scriptable)
- Attaching to a running Hermes TUI process
- Vitest / Ink component debugging
- Heap snapshots and CPU profiles via CDP

**Minimal recipe:**

```bash
node --inspect-brk path/to/script.js
# In debug> prompt:
debug> sb('script.js', 42)   # set breakpoint at line 42
debug> cont
```

## Common Patterns (Both Ecosystems)

| Pattern | Python | Node |
|---------|--------|------|
| Break on a line | `breakpoint()` | `sb('file.js', 42)` then `cont` |
| Break on function entry | `b func_name` | `sb('funcName')` then `cont` |
| Inspect locals | `p variable` | `repl` → type variable |
| Step over | `n` | `n` |
| Step into | `s` | `s` |
| Continue | `c` | `c` |
| Backtrace | `w` or `bt` | `bt` |
| Conditional breakpoint | `b file:line, condition` | same syntax |
| Watch expression | `display expr` | `watch('expr')` |

## Verification Checklist

- [ ] First breakpoint actually fires (if not: check `PYTHONBREAKPOINT`, `--inspect-brk`, attach latency)
- [ ] `where` / `bt` shows the expected call stack
- [ ] The inspected state (locals, closure vars) matches what you expected
- [ ] No stray `breakpoint()` / `set_trace()` / `debugpy.listen` left in committed code

## Security Notes

- Always bind debuggers to `127.0.0.1` (the default). `--inspect=0.0.0.0:9229` exposes arbitrary code execution.
- `td_execute_python` in related TouchDesigner context has unrestricted filesystem access — same caution applies to any debugger REPL running as the same process user.
- Debuggers can evaluate arbitrary code in the paused frame — treat them like a REPL in production context.
