---
name: code-review-and-audit
description: Review code (diff + test + subagent), pre-commit gates, local diff scanning,
  simplifications, source-level repo audits, LOC analysis, research and academic review
  — class-level guidance for the full review-to-audit workflow.
version: 1.0.0
author: Hermes Agent (umbrella consolidation)
license: MIT
metadata:
  hermes:
    tags:
      trigger:
      - 代码审查
      - 审计
      - code review
      - 安全
      - 质量
      disable:
      - code_development
      - deep_review
    related_skills:
    - github
    - lm-evaluation-harness
---
# Code Review & Audit — Class-Level Guidance

This umbrella consolidates the full spectrum of code review, diff auditing,
pre-commit quality gates, source-level inspection, LOC analysis, research review,
and LLM benchmarking under one entry point.

## 1. PR Code Review

See absorbed skill `github-code-review` for:
- Pre-push local diff scanning (secrets, TODOs, style)
- Finding a reviewer / opening a PR
- Submitting formal PR review (APPROVE / REQUEST_CHANGES / COMMENT)
- Reviewing async (comment-only) vs blocking (CHANGES_REQUESTED)
- Pull request comments via `gh pr review` and atomic inline comments via REST

Key command: `gh pr checkout <number>` then inspect with `gh pr diff <number>`.

## 2. Pre-Commit Quality Gate

See absorbed skill `requesting-code-review` for:
- Running baseline tests before committing
- Independent-reviewer subagent pattern
- Diff scan (secrets, injects, TODOs) before every push
- Decision gate: fix/iterate before merge vs note-and-land

## 3. Receiving a Review

When an externaler or user submits feedback, apply Hermes AGENTS.md §5:

- **Forbidden** performative agreement: "你说得对", "好建议", "让我现在改".
- **Required**: restate the requirement in your own words, ask clarifying
  questions, or fix directly with an evidence-based change.
- Report back with: `Fixed. <change description>` or `Good catch — <issue>. Fixed in <file>`

## 4. Simplify & Clean Up

See absorbed skill `simplify-code` for:
- 3-agent parallel decomposition (reuse / quality / efficiency)
- Identifying simplify targets: qualification chains, gym imports, repeated patterns
- Refactoring recipes for each subtask

## 5. Source-Level Repo Audit

See absorbed skill `repo-source-audit` for:
- Four-stage radar: sitemap → raw.github → grep → read with offsets
- Extracting canonical config keys, defaults, and deprecation status
- Citing line numbers from landed files (not guesses)

## 6. Codebase Inspection (LOC)

See absorbed skill `codebase-inspection` for:
- `pygount` command patterns with `--folders-to-skip` 
- Language breakdown, file counts, code-vs-comment ratios
- Filtering by suffix and output formats (summary / JSON / pipe)

## 7. LLM Benchmarking (lm-eval-harness)

See absorbed skill `evaluating-llms-harness` for:
- 60+ academic benchmarks (MMLU, GSM8K, HumanEval, TruthfulQA, etc.)
- Standard, vLLM, and multi-GPU evaluation modes
- Training progress tracking with EvalHarnessCallback
- Model comparison tables

Note: located at `mlops/evaluation/lm-evaluation-harness/` due to its MLOps
domain; this section is its functional home for review-orchestration purposes.

## 8. Research Literature Review

See absorbed skill `research-paper-writing` for:
- Defining scope, finding papers, taking notes, writing up findings
- Reviewing a field and identifying research gaps

Notes for agents invoking this section:
- Wide paper discovery: use `arxiv` skill search patterns.
- Paper reading: use `obsidian` or `llm-wiki` to file findings.
- When producing formal prose for a review: apply `humanizer` (creative/) to
  restore natural voice.
