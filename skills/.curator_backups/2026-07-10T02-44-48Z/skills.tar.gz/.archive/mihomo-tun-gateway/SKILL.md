---
name: mihomo-tun-gateway
description: '在 Debian/Ubuntu 上部署 Mihomo TUN 模式旁路由网关——让局域网其他主机通过本机代理流量。 适用于 x86_64
  服务器/虚拟机作为透明代理网关的场景。

  '
metadata:
  hermes:
    tags:
    - mihomo
    - clash
    - tun
    - 透明代理
    - 旁路由
    - 旁路由网关
    - iptables
    - 代理网关
    - openwrt替代
    - 透明网关
    - mihomo安装
    - mihomo配置
    skill_type: workflow
    priority: high
platforms:
- linux
environments:
- debian
- ubuntu
- armbian
requires_tools: []
---
# Mihomo TUN 旁路由网关

## 适用场景

- 本机（Debian/Ubuntu）作为局域网代理出口，其他设备改网关即可整屋走代理
- 不想跑 OpenWrt 软路由，只需要在现有系统上跑透明代理
- 分流需求：国内 IP 直连，境外流量走代理节点

## 环境要求

| 项目 | 要求 |
|---|---|
| 系统 | Debian/Ubuntu/Armbian (x86_64) |
| 内存 | ≥ 1GB |
| 网卡 | 至少一张可访问局域网的网卡 |
| ip_forward | 必须开启 |
| 节点 | SS/Shadowsocks 节点（配置里已有示例） |

## 架构

```
局域网主机 → 网关指向本机 → MihomoTun TUN 设备 → mihomo 分流
                                              ├─ 国内 IP → DIRECT (直连)
                                              └─ 境外 IP → Proxy 节点
                                                         └─ MASQUERADE → enp4s0 出公网
```

---

## 安装

### Task 1: 安装 mihomo 内核

```bash
# 查最新版（当前 v1.19.27）
curl -sL "https://api.github.com/repos/MetaCubeX/mihomo/releases/latest" | grep -E '"tag_name"|"name".*linux-amd64.deb' | head -3

# 下载 deb 包安装（推荐，比二进制更干净）
wget -q "https://github.com/MetaCubeX/mihomo/releases/download/v1.19.27/mihomo-linux-amd64-v1.19.27.deb" -O /tmp/mihomo.deb
sudo dpkg -i /tmp/mihomo.deb

# 验证
mihomo -v
# 应输出: Mihomo Meta v1.19.27 linux amd64 with go1.26.4 ...
```

**注意**: deb 安装路径是 `/usr/bin/mihomo`，不是 `/usr/local/bin/mihomo`。后续 systemd service 和配置文件里都要用这个路径。

### Task 2: 下载 geo 数据文件

```bash
sudo mkdir -p /etc/mihomo
sudo chown $USER:$USER /etc/mihomo

cd /etc/mihomo
wget -q "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/geosite.dat" -O geosite.dat
wget -q "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/geoip.dat" -O geoip.dat
wget -q "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/country.mmdb" -O country.mmdb

# 验证文件大小（正常: geosite ~4MB, geoip ~18MB, mmdb ~8MB）
ls -lh /etc/mihomo/
```

### Task 3: 写入配置文件

配置文件路径: `/etc/mihomo/config.yaml`

关键配置项说明：

```yaml
# 基础监听
mixed-port: 7898          # HTTP(S)/SOCKS5 混合代理端口
redir-port: 7899          # REDIR 代理端口（TUN 透明代理用）
allow-lan: true           # 允许局域网访问
bind-address: "*"         # 监听所有网卡
mode: rule               # 规则分流模式
log-level: info
ipv6: false
external-controller: 0.0.0.0:9090  # RESTful API（局域网控制用）
secret: ""               # API 密钥，空=不验证（仅限私有网络使用）

# TUN 透明网关（核心）
tun:
  enable: true
  stack: system           # Linux 推荐 system
  device: MihomoTun       # TUN 设备名，可自定义
  auto-route: true        # 自动添加路由，将流量导入 TUN
  auto-detect-interface: true  # 自动检测出口网卡（通常即内网网卡）
  dns-hijack:
    - any:53              # 劫持所有 DNS 请求（防 DNS 泄露）

# DNS 配置（配合 fake-ip）
dns:
  enable: true
  listen: 0.0.0.0:53
  enhanced-mode: fake-ip  # fake-ip 提升性能与隐私
  fake-ip-range: 198.18.0.1/16
  fake-ip-filter:
    - "*.lan"
    - "localhost.ptlogin2.qq.com"
    - "*.msftconnecttest.com"
    - "*.msftncsi.com"
  nameserver:             # 国内 DNS
    - 223.5.5.5
    - 119.29.29.29
  fallback:               # 境外 DNS（fallback-filter 判定后使用）
    - tls://8.8.8.8
    - tls://1.1.1.1
  fallback-filter:
    geoip: true
    geoip-code: CN        # GeoIP CN 的 IP 走国内 DNS

# Geo 数据路径（必须与 Task 2 文件对应）
geodata-mode: true
geodata:
  geosite: /etc/mihomo/geosite.dat
  geoip: /etc/mihomo/geoip.dat
  mmdb: /etc/mihomo/country.mmdb

# 节点（替换为真实节点）
proxies:
  - name: "ss"
    type: ss
    server: 149.88.88.236
    port: 443
    cipher: chacha20-ietf-poly1305
    password: "你的密码"
    udp: true

# 策略组
proxy-groups:
  - name: "Proxy"
    type: select
    proxies:
      - "ss"
      - DIRECT
  - name: "自动选择"
    type: url-test
    proxies:
      - "ss"
    url: "https://www.gstatic.com/generate_204"
    interval: 300

# 分流规则（按优先级排序）
rules:
  - IP-CIDR,192.168.0.0/16,DIRECT,no-resolve  # 局域网
  - IP-CIDR,10.0.0.0/8,DIRECT,no-resolve
  - IP-CIDR,172.16.0.0/12,DIRECT,no-resolve
  - IP-CIDR,127.0.0.0/8,DIRECT,no-resolve
  - IP-CIDR,100.64.0.0/10,DIRECT,no-resolve
  - GEOSITE,private,DIRECT   # 私有域名
  - GEOSITE,cn,DIRECT         # 国内网站
  - GEOIP,cn,DIRECT           # 国内 IP
  - MATCH,Proxy               # 未匹配流量走代理
```

写入命令：

```bash
# 用 write_file 写到 /tmp，再搬进去（平台限制 sudo heredoc）
# 本地操作:
#   把上面的 yaml 内容保存为 /tmp/mihomo-config.yaml
#   然后:
sudo cp /tmp/mihomo-config.yaml /etc/mihomo/config.yaml
sudo chmod 644 /etc/mihomo/config.yaml

# 验证配置语法
sudo mihomo -t -d /etc/mihomo -f /etc/mihomo/config.yaml
# 期望输出: configuration file /etc/mihomo/config.yaml test is successful
```

### Task 3.5: 防回环 — 代理节点 IP 加入 DIRECT 规则（必做）

mihomo 开启 `auto-route: true` 后会注入路由表 `table 2022` 将所有流量导入 MihomoTun 设备。这包括 mihomo **自身到代理节点的出站连接**。如果不将节点 IP 标记为 DIRECT，会发生：

1. mihomo 连接 `proxy-server-ip:443` → 路由表 2022 → MihomoTun
2. mihomo 在 TUN 侧收到自己的连接 → MATCH 规则命中 → Proxy[ss]
3. 再次尝试连接节点 → 又入 TUN → 回环

**表现**：大量 CLOSE-WAIT 连接到节点 IP，节点间歇性 timeout，`ss -tnp dst <node-ip>` 显示连接堆积。

修复：在 rules 段**最开头**（MATCH 之前）添加节点 IP 的 DIRECT 规则。

```yaml
rules:
  # 代理节点直连（防回环 — 必须在 MATCH 之前）
  - IP-CIDR,<你的节点IP>/32,DIRECT,no-resolve
  # ... 其余局域网/国内规则
  - MATCH,Proxy
```

```bash
# 找到节点 IP
grep '^  server:' /etc/mihomo/config.yaml

# 插入到 rules: 之后第一行（替换 <节点IP> 为实际 IP）
sudo sed -i '/^rules:/a\  - IP-CIDR,<节点IP>/32,DIRECT,no-resolve' /etc/mihomo/config.yaml

# 验证
sudo mihomo -t -d /etc/mihomo -f /etc/mihomo/config.yaml
sudo systemctl restart mihomo

# 验证连接不再堆积
sleep 3
ss -tnp dst <节点IP> | wc -l
# 期望: 0（新建连接不会堆积 CLOSE-WAIT）
```

**识别技巧**：如果 `ip route get <节点IP>` 显示 `via 198.18.0.2 dev MihomoTun table 2022`，说明节点流量被 auto-route 捕获，必须加 DIRECT 规则。

**多节点场景**：每个节点 IP 都需要一条 DIRECT 规则。固定 IP 逐条添加；订阅更新场景维护脚本在每次更新配置后自动注入。

### Task 3.6: DNS nameserver 优化 — TLS DNS 不要混入 nameserver（推荐）

mihomo 的 DNS 查询顺序：先查 `nameserver` 列表，然后用 `fallback-filter`（GeoIP cn）判定返回 IP 是否国内，不是则再查 `fallback` 列表。

**关键问题**：如果将 `tls://8.8.8.8` 等境外 TLS DNS 放入 `nameserver`，国内域名的每次查询都会先做一次 DoT 握手（增加 ~200ms 延迟），直到 fallback-filter 判定为 CN 后才用上 223.5.5.5 的结果。

**正确做法**：
- `nameserver` 只放国内纯 UDP DNS：`223.5.5.5` / `119.29.29.29`
- `fallback` 放境外 TLS DNS：`tls://8.8.8.8` / `tls://1.1.1.1`

```yaml
dns:
  enable: true
  enhanced-mode: fake-ip
  nameserver:             # 仅限国内 DNS
    - 223.5.5.5
    - 119.29.29.29
  fallback:               # 境外 DNS（仅 fallback-filter 判定后使用）
    - tls://8.8.8.8
    - tls://1.1.1.1
    - https://dns.google/dns-query
```

验证当前配置：
```bash
sudo sed -n '/^  nameserver:/,/^  fallback:/p' /etc/mihomo/config.yaml
# nameserver 不应包含 tls:// 行
sudo sed -n '/^  fallback:/,/^  fallback-filter:/p' /etc/mihomo/config.yaml
# fallback 应有 tls:// 行
```

如果发现 TLS DNS 混入 nameserver，移除：
```bash
sudo sed -i '/^  nameserver:/,/^  fallback:/{/tls:\/\//d}' /etc/mihomo/config.yaml
sudo systemctl restart mihomo
```

### Task 4: 释放 53 端口

systemd-resolved 默认占用 53 端口，会导致 mihomo DNS 启动失败。

```bash
sudo systemctl disable --now systemd-resolved
sudo unlink /etc/resolv.conf 2>/dev/null || true
echo "nameserver 223.5.5.5" | sudo tee /etc/resolv.conf

# 验证 53 端口已被释放（systemd-resolved 停后应为空闲）
ss -ulnp | grep :53
# 期望: 无输出（或只有 mihomo 自己）
```

### Task 4.5: 加固 external-controller（必做）

旁路由暴露在局域网，`external-controller: 0.0.0.0:9090` 配 `secret: ""` 等于任何能连到本机的设备都能无密码控制 mihomo（改规则、看流量）。

```bash
# 生成随机 secret（24 位字母数字）
SECRET=$(python3 -c "import secrets,string; print(''.join(secrets.choice(string.ascii_letters+string.digits) for _ in range(24)))")
sudo sed -i "s/^secret: .*/secret: \"$SECRET\"/" /etc/mihomo/config.yaml
grep '^secret:' /etc/mihomo/config.yaml
```

改完需 `sudo systemctl restart mihomo` 生效。

### Task 4.6: 关闭 IPv6 防泄漏（必做）

`ipv6: false` 只是 mihomo 不处理 v6，但主机若 `accept_ra=1` 拿了 v6 默认路由，局域网设备可能走 IPv6 直连绕过 mihomo（DNS 不劫持 AAAA）。

```bash
sudo sysctl -w net.ipv6.conf.all.disable_ipv6=1
sudo sysctl -w net.ipv6.conf.default.disable_ipv6=1
# 持久化：Ubuntu 26.04 默认无 /etc/sysctl.conf，直接 tee 会创建（已验证可行）
grep -q 'disable_ipv6' /etc/sysctl.conf 2>/dev/null || printf 'net.ipv6.conf.all.disable_ipv6=1\\nnet.ipv6.conf.default.disable_ipv6=1\\n' | sudo tee -a /etc/sysctl.conf
# 验证
sysctl net.ipv6.conf.all.disable_ipv6
```

### Task 4.7: 持久化 ip_forward（推荐）

mihomo 的 `auto-route: true` 会在启动时设置 `net.ipv4.ip_forward=1`，但如果 mihomo 因节点不可用反复崩溃重启，存在 ip_forward=0 的空窗期。建议独立持久化：

```bash
printf 'net.ipv4.ip_forward=1\n' | sudo tee /etc/sysctl.d/90-forward.conf
sudo sysctl -p /etc/sysctl.d/90-forward.conf
# 验证
sysctl -n net.ipv4.ip_forward
# 期望: 1
```

### Task 4.8: QUIC(UDP/443) 嗅探盲区拦截（推荐）

mihomo sniffer 只处理 TCP(TLS/HTTP) 的 SNI，不嗅探 QUIC(UDP/443)。YouTube / 新版 Chrome 等走 QUIC 时 SNI 嗅探不到，规则匹配退化为仅 IP，导致分流不准。

修复：在 `filter FORWARD` 链拦掉局域网客户端经 TUN 出站的 `udp dport 443`，强制回落 TCP 以启用 TLS SNI 嗅探。**只拦客户端流量，不拦 mihomo 自身节点连接**（mihomo 的 ss 流量由本机进程发出，不在 FORWARD 链）。

```bash
# 找 mihomo 注入的第一条 accept 规则 handle（enp4s0 -> MihomoTun）
HANDLE=$(sudo nft -a list chain ip filter FORWARD 2>/dev/null | grep 'iifname "enp4s0" oifname "MihomoTun" counter' | head -1 | grep -oE 'handle [0-9]+' | awk '{print $2}')
sudo nft insert rule ip filter FORWARD position "$HANDLE" iifname "enp4s0" oifname "MihomoTun" udp dport 443 drop
# 验证
sudo nft list ruleset 2>/dev/null | grep 'udp dport 443 drop'
```

**持久化（关键）**：nftables 规则是运行时的，mihomo 重启会重建 FORWARD 链导致 drop 丢失。用 `ExecStartPost` 在 TUN 起来后自动重注：

写注入脚本 `/usr/local/bin/mihomo-quic-drop.sh`：
```bash
cat <<'EOF' | sudo tee /usr/local/bin/mihomo-quic-drop.sh >/dev/null
#!/bin/sh
# 注入 QUIC(UDP/443) 拦截：强制局域网客户端经 TUN 时回落 TCP 以启用 SNI 嗅探
set -e
for i in $(seq 1 10); do
  ip link show MihomoTun >/dev/null 2>&1 && break
  sleep 0.5
done
if nft list ruleset 2>/dev/null | grep -q 'iifname "enp4s0" oifname "MihomoTun" udp dport 443 drop'; then
  exit 0
fi
HANDLE=$(nft -a list chain ip filter FORWARD 2>/dev/null | grep 'iifname "enp4s0" oifname "MihomoTun" counter' | head -1 | grep -oE 'handle [0-9]+' | awk '{print $2}')
if [ -n "$HANDLE" ]; then
  nft insert rule ip filter FORWARD position "$HANDLE" iifname "enp4s0" oifname "MihomoTun" udp dport 443 drop
fi
EOF
sudo chmod 0755 /usr/local/bin/mihomo-quic-drop.sh
```

在 `mihomo.service` 的 `[Service]` 段 `ExecStart` 之后加一行：
```ini
ExecStartPost=/usr/local/bin/mihomo-quic-drop.sh
```
然后 `sudo systemctl daemon-reload && sudo systemctl restart mihomo`，重启后 `nft list ruleset | grep 'udp dport 443 drop'` 应自动出现。

**注意**：本机用 nftables 作主框架（iptables 是兼容层），不要用 `iptables -A` 加这条规则——会被 nftables 重置。直接操作 nftables。

### Task 5: 配置 iptables NAT 转发

```bash
# MASQUERADE: 让经本机转发的流量从 enp4s0 NAT 出公网
# （注意: 将 enp4s0 替换为你实际的内网网卡名）
sudo iptables -t nat -A POSTROUTING -o enp4s0 -j MASQUERADE

# FORWARD: 允许 TUN 和内网网卡之间转发
sudo iptables -A FORWARD -i enp4s0 -o MihomoTun -j ACCEPT
sudo iptables -A FORWARD -i MihomoTun -o enp4s0 -j ACCEPT

# 验证
sudo iptables -t nat -L POSTROUTING -n -v | grep MASQUERADE
# 期望: 看到 enp4s0 MASQUERADE 规则
```

### Task 6: 持久化 iptables 规则

安装 iptables-persistent（注意交互式弹窗问题）：

```bash
# 方式一: debconf 预设答案（推荐）
echo iptables-persistent iptables-persistent/rules-v4 boolean true | sudo debconf-set-selections
echo iptables-persistent iptables-persistent/rules-v6 boolean true | sudo debconf-set-selections
sudo apt-get install -y iptables-persistent

# 方式二: 手动保存（如 debconf 失败）
sudo bash -c 'iptables-save > /etc/iptables/rules.v4'
sudo systemctl enable --now netfilter-persistent
```

### Task 7: 创建 systemd 服务

```bash
sudo tee /etc/systemd/system/mihomo.service > /dev/null <<'EOF'
[Unit]
Description=Mihomo Proxy (Clash.Meta) TUN Gateway
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/mihomo -d /etc/mihomo -f /etc/mihomo/config.yaml
Restart=always
RestartSec=5
User=root

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now mihomo

# 验证
systemctl status mihomo --no-pager | head -12
# 期望: Active: active (running)
```

---

## 进阶: 修复 QUIC(UDP/443) 嗅探盲区（强烈推荐）

mihomo sniffer 只处理 TCP(TLS/HTTP) 的 SNI/Host 嗅探，**不处理 QUIC(UDP/443)**。
YouTube、新版 Chrome、部分 App 默认走 QUIC，此时 SNI 嗅探不到，规则匹配退化为仅按 IP，
导致本应 DIRECT 的国内 QUIC 流量被误送代理、或本应代理的流量分类错误。

**修法**: 在 FORWARD 链丢弃局域网客户端经 TUN 出站的 UDP/443，强制回落 TCP 以启用嗅探。

### nftables 环境（主流，Docker/mihomo 用 nftables 动态管规则）

系统若 `command -v nft` 存在且 `iptables` 是兼容层，直接改 iptables 持久化文件不会在 mihomo
重启后自动恢复（mihomo 每次重启重建自己的 FORWARD accept 规则）。正确做法：写一个注入脚本，
挂到 `mihomo.service` 的 `ExecStartPost=`。

**注入脚本** `/usr/local/bin/mihomo-quic-drop.sh`（可复制本 skill 的 `scripts/mihomo-quic-drop.sh`，已带去重+等待 TUN 就绪）：

```bash
#!/bin/sh
# 注入 QUIC(UDP/443) 拦截：强制局域网客户端经 TUN 时回落 TCP 以启用 SNI 嗅探
# 仅在 mihomo TUN 已建立后由 mihomo.service ExecStartPost 调用
set -e

for i in $(seq 1 10); do
  ip link show MihomoTun >/dev/null 2>&1 && break
  sleep 0.5
done

if nft list ruleset 2>/dev/null | grep -q 'iifname "enp4s0" oifname "MihomoTun" udp dport 443 drop'; then
  exit 0
fi

HANDLE=$(nft -a list chain ip filter FORWARD 2>/dev/null | grep 'iifname "enp4s0" oifname "MihomoTun" counter' | head -1 | grep -oE 'handle [0-9]+' | awk '{print $2}')
if [ -n "$HANDLE" ]; then
  nft insert rule ip filter FORWARD position "$HANDLE" iifname "enp4s0" oifname "MihomoTun" udp dport 443 drop
fi
```

> 网卡名 `enp4s0` 替换为实际内网网卡（用 `ip -br link` 查）。脚本带去重 + 等待 TUN 就绪，
> 可重复执行。插入位置在 mihomo 第一条 `enp4s0→MihomoTun` accept 规则 **之前**，否则被 accept 短路。

**挂到 systemd**：

```bash
sudo cp /etc/systemd/system/mihomo.service /etc/systemd/system/mihomo.service.bak
sudo sed -i '/^ExecStart=\/usr\/bin\/mihomo/a ExecStartPost=\/usr\/local\/bin\/mihomo-quic-drop.sh' /etc/systemd/system/mihomo.service
sudo systemctl daemon-reload
sudo systemctl restart mihomo
sleep 3
# 验证：重启后规则应自动回来
sudo nft list ruleset 2>/dev/null | grep 'udp dport 443 drop' && echo "OK 自动注入"
```

### iptables-only 环境（无 nftables）

```bash
sudo iptables -I FORWARD -i enp4s0 -o MihomoTun -p udp --dport 443 -j DROP
sudo bash -c 'iptables-save > /etc/iptables/rules.v4'
```

### 单节点场景说明

只有 1 个代理节点时，`自动选择`(url-test) 组永远选它，等于摆设。保留无妨，但加注释标注：
`# 当前仅含单个节点, url-test 无实际择优作用; 加入第二个及以上节点后此组才生效`。
第二节点加入后该组自动生效，无需改结构。

---

## 验证清单

```bash
# 1. 服务运行
systemctl is-active mihomo
# 期望: active

# 2. 端口监听
ss -tlnp | grep -E '7898|7899|:53\b|9090'
# 期望: 四行，分别对应 mixed-port/redir-port/DNS/API

# 3. TUN 设备
ip link show MihomoTun
# 期望: POINTOPOINT MULTICAST NOARP UP

# 4. 路由表（mihomo auto-route 接管）
ip route show table all | grep -E 'default.*Mihomo|198.18'
# 期望: default via 198.18.0.2 dev MihomoTun table 2022

# 5. NAT 规则
sudo iptables -t nat -L POSTROUTING -n -v | grep enp4s0 | grep MASQUERADE
# 期望: 有输出

# 6. DNS fake-ip
dig @127.0.0.1 +short www.google.com
# 期望: 198.18.x.x

# 7. 代理出口测试
curl -s --socks5 127.0.0.1:7898 -o /dev/null -w "%{http_code}" https://www.google.com
# 期望: 302 或 200

# 8. API 可访问
curl -s http://127.0.0.1:9090/proxies | python3 -c "import sys,json; d=json.load(sys.stdin); print('nodes:', list(d.get('proxies',{}).keys()))"
# 期望: 看到 ss/DIRECT/PROXY 等节点

# 9. 防回环验证：代理节点连接数
PROXY_IP=$(grep '^  server:' /etc/mihomo/config.yaml | awk '{print $2}')
ss -tnp dst $PROXY_IP | wc -l
# 期望: 0 或少量 ESTAB（无 CLOSE-WAIT 堆积）

# 10. DNS nameserver 安全检查
sudo sed -n '/^  nameserver:/,/^  fallback:/p' /etc/mihomo/config.yaml | grep -c tls
# 期望: 0（nameserver 不应含 TLS DNS）
```

---

## 使用方法

### 客户端配置

在局域网其他设备上修改两项：

| 设置项 | 值 |
|---|---|
| 默认网关 | 本机 IP（例如 `192.168.33.152`） |
| DNS 服务器 | 本机 IP（配合 fake-ip 使用） |

**Windows**: 设置 → 网络和 Internet → 适配器选项 → IPv4 属性 → 填网关和 DNS
**macOS**: 系统设置 → 网络 → 高级 → TCP/IP → 手动配置 IPv4 → 填网关 → DNS 标签填本机 IP
**Linux**: `sudo nmcli` 或编辑 `/etc/netplan/*.yaml`

### mihomo API 控制（可选）

API 地址: `http://本机IP:9090`

```bash
# 查看节点
curl -s http://127.0.0.1:9090/proxies | python3 -m json.tool

# 切换策略组
curl -X PUT http://127.0.0.1:9090/proxies/Proxy -H "Content-Type: application/json" -d '{"name":"DIRECT"}'
curl -X PUT http://127.0.0.1:9090/proxies/Proxy -H "Content-Type: application/json" -d '{"name":"ss"}'

# 查看配置
curl -s http://127.0.0.1:9090/config | python3 -m json.tool

# 查看日志
journalctl -u mihomo -f
```

### 切换节点

方式一（API）:
```bash
# 切 ss 节点
curl -X PUT http://127.0.0.1:9090/proxies/Proxy -d '{"name":"ss"}'
```

方式二（配置文件）: 修改 `/etc/mihomo/config.yaml` 中 `proxy-groups[0].proxies` 顺序，或直接替换 `proxies` 节点内容，然后 `sudo systemctl restart mihomo`。

---

## 维护

### 更新 mihomo

```bash
# 1. 查最新版
LATEST=$(curl -sL "https://api.github.com/repos/MetaCubeX/mihomo/releases/latest" | grep '"tag_name"' | cut -d'"' -f4)
echo "Latest: $LATEST"

# 2. 下载并重装
wget -q "https://github.com/MetaCubeX/mihomo/releases/download/${LATEST}/mihomo-linux-amd64-v${LATEST}.deb" -O /tmp/mihomo.deb
sudo dpkg -i /tmp/mihomo.deb

# 3. 验证
mihomo -v

# 4. 重启服务
sudo systemctl restart mihomo

# 5. 确认运行
systemctl status mihomo --no-pager | head -5
```

### 更新 geo 数据

```bash
cd /etc/mihomo
wget -q "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/geosite.dat" -O geosite.dat
wget -q "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/geoip.dat" -O geoip.dat
wget -q "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download/country.mmdb" -O country.mmdb
sudo systemctl restart mihomo
```

### 查看日志

```bash
# 实时日志
sudo journalctl -u mihomo -f

# 最近 100 行
sudo journalctl -u mihomo --no-pager -n 100

# 错误信息
sudo journalctl -u mihomo --no-pager -p err
```

### 重启服务

```bash
sudo systemctl restart mihomo
```

### 完全卸载

```bash
sudo systemctl stop mihomo
sudo systemctl disable mihomo
sudo rm /etc/systemd/system/mihomo.service
sudo rm -rf /etc/mihomo
sudo apt-get remove --purge -y mihomo

# 恢复 systemd-resolved（如果需要）
sudo systemctl enable systemd-resolved
sudo ln -sf /run/systemd/resolve/resolv.conf /etc/resolv.conf

# 清除 iptables 规则（重启自动清，需重启）
sudo iptables -t nat -F
sudo iptables -F FORWARD
sudo rm /etc/iptables/rules.v4
```

### 常见故障

**EXEC 203 (找不到可执行文件)**
- 原因: systemd service 里路径写成了 `/usr/local/bin/mihomo`，但 deb 安装在 `/usr/bin/mihomo`
- 修复: `sudo sed -i 's|/usr/local/bin/mihomo|/usr/bin/mihomo|g' /etc/systemd/system/mihomo.service`
- 然后: `sudo systemctl daemon-reload && sudo systemctl restart mihomo`

**53 端口被占用 (address already in use)**
- 原因: systemd-resolved 未关闭
- 修复: `sudo systemctl disable --now systemd-resolved && sudo unlink /etc/resolv.conf; echo "nameserver 223.5.5.5" | sudo tee /etc/resolv.conf`

**TUN 设备不存在**
- 原因: mihomo 未正常启动或权限不足
- 修复: `sudo systemctl restart mihomo` 等待 3 秒后 `ip link show MihomoTun`

**代理不通但本机通**
- 原因: 网卡名不是 enp4s0（配置文件里需要对应实际网卡名）
- 修复: 用 `ip -br link` 查实际网卡名，更新配置和 iptables 规则

**FORWARD/NAT 规则重复**（Docker 共存时）
- 原因: Docker 的 iptables 兼容层 + netfilter-persistent + mihomo 各自写入，产生重复的 ACCEPT 和 MASQUERADE 规则
- 表现: `iptables -S FORWARD | grep MihomoTun` 看到多条 ACCEPT，`iptables -t nat -S POSTROUTING | grep enp4s0` 看到多条 MASQUERADE
- 修复: 去重后用 `sudo bash -c 'iptables-save > /etc/iptables/rules.v4'` 重存
- 预防: 执行 iptables 命令前先检查重复，不要重复追加

**iptables 规则重启后丢失**
- 原因: 未安装 iptables-persistent 或规则未保存
- 修复: `sudo bash -c 'iptables-save > /etc/iptables/rules.v4'`

---

## 配置文件完整模板

路径: `/etc/mihomo/config.yaml`

完整模板见 Skill 关联文件 `references/config-template.yaml`

---

## References
## 已验证实战环境（fnubuntu, 2026-07-07）

| 项 | 实际状态 |
|---|---|
| 主机 | fnubuntu (Ubuntu 26.04, x86_64 虚拟机) |
| 内网网卡 | enp4s0, IP 192.168.33.152/24, 网关 192.168.33.1 |
| mihomo 路径 | /usr/bin/mihomo (deb 安装), 配置 /etc/mihomo/config.yaml |
| 防火墙框架 | nftables 为主, iptables 是兼容层 (nftables.service disabled, 规则由 Docker/mihomo 动态注入) |
| 节点 | 单固定 SS 节点 (149.88.88.236:443), 无冗余 |
| external-controller | 0.0.0.0:9090 + secret 已设 (随机 24 位) |
| IPv6 | 已 disable (运行时 + /etc/sysctl.conf 持久化) |
| QUIC 拦截 | FORWARD 链 `iifname enp4s0 oifname MihomoTun udp dport 443 drop`, 经 ExecStartPost 脚本持久化 |
| 重启恢复 | mihomo.service 重启后 QUIC drop 规则自动重注 ✅ |

**2026-07-07 审计后修复验证**：
- 代理节点回环：修复前 14+ CLOSE-WAIT 连接堆积，`ip route get 节点IP` 走 table 2022 → 加 DIRECT 规则后连接数归零
- iptables 规则去重：FORWARD ACCEPT 4→2, MASQUERADE enp4s0 2→1
- ip_forward 持久化：写入 `/etc/sysctl.d/90-forward.conf`
- DNS nameserver 优化：移除 nameserver 中的 tls:// 行（仅留 223.5.5.5/119.29.29.29）
- SOCKS5 出口：Google 200 (6s), 百度 DIRECT 200 (0.08s)
- DNS fake-ip: 198.18.0.x, API 认证 401/200 正常

**关键结论**：

**关键结论**：
- 不要在 iptables 兼容层加 FORWARD 规则, 直接操作 nftables (mihomo 重启会重置 iptables 视图)。
- `/etc/sysctl.conf` 在 Ubuntu 26.04 默认不存在, `tee -a` 会自动创建, 无需先 touch。
- 单节点场景下 `proxy-groups` 的 url-test/auto 组无意义, 保留即可, 加节点后自动生效。

## References
- 部署后审计清单: `references/post-deploy-audit.md` — 捕获代理回环、DNS 优化、规则去重、sysctl 持久化等易遗漏项
- mihomo 官方仓库: https://github.com/MetaCubeX/mihomo
- meta-rules-dat (geo 数据): https://github.com/MetaCubeX/meta-rules-dat
- TUN 模式文档: https://wiki.metacubex.one/tun
- GeoIP 规则说明: https://wiki.metacubex.one/rule/geoi