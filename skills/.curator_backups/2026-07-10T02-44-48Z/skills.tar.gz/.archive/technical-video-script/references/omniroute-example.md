# OmniRoute 视频脚本（参考示例）

完整脚本见 `/home/lan/OmniRoute-video-script.md`

## 关键结构

- **定位**：本地 AI Gateway — 工具只管干活，模型调度交给网关
- **时长**：10-12 分钟
- **观众**：AI 编程工具用户、本地 Agent 架构玩家、想省 API 成本的人
- **核心功能拆解**：Provider 自动路由 / 三层容灾 / RTK+Caveman 压缩 / MCP+A2A
- **慎讲**：免费 Token 数量（区分 steady / first-month / uncapped / theoretical）
- **演示路径**：npm install → omniroute → Dashboard → 连 Provider → 工具指向 localhost:20128/v1

## 调研方法

| 步骤 | 工具 | 产出 |
|------|------|------|
| 克隆仓库 | `git clone --depth 1` | 完整源码 |
| README 定位 | `read_file` | 项目描述、Quick Start |
| 版本/依赖 | `package.json` + `npm view` | Engine 约束、License |
| GitHub 元数据 | `gh repo view --json ...` | Stars、Forks、描述 |
| 文档深度 | `docs/*.md` | Auto-Combo、Resilience、Compression、CLI |
| 物证 | `file` + `identify` | 截图尺寸、格式 |

## 拍摄避坑（复用）

1. 不把免费额度讲成稳定无限可用
2. 不把中文 README 旧数字当最终事实
3. 不展示真实 API Key / OAuth token
4. 不承诺免费 Provider 不封、不限速、不违反条款
5. 不只讲免费 — 重点讲网关、调度、压缩、容灾、Agent 协议
