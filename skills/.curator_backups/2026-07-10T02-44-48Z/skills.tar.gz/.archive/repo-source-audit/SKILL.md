---
name: repo-source-audit
description: Audit an open-source project's source code for canonical semantics —
  config keys, default behaviors, validation rules, deprecation status — when official
  docs are missing, SPA-rendered, paywalled, or unreliable. Pulls evidence directly
  from schemas, default-config dicts, and CLI source so answers carry line numbers,
  not guesses. Use when a user asks "how does X actually work under the hood", "what
  config keys exist", or "what's the canonical way to set Y" for any programming-language
  project on GitHub/GitLab.
metadata:
  hermes:
    tags:
      trigger:
      - 代码审计
      - 源码分析
      - 审计
      - 安全
      - code audit
      disable:
      - deep_review
      - read_only
---
 repo-source-audit — source-code-driven canonical answers

When the docs site is a SPA, behind auth, or just thin, the source code is the truth. This skill walks a four-stage ladder from cheapest to most-invasive probe so you usually get an evidence-backed answer without burning tokens.

## When to use

  • User asks "what's the canonical setting / config key / default value for X"
  • Docs site returns same byte-count for every sub-URL (SFA — SPA shell, pre-hydration)
  • Official docs disagree with observed CLI behavior, or doc just says "see source"
  • You need deprecation status, env-var-to-config migration, or hidden validation rules
  • Sibling projects (langfuse, sqlite, etc) — anyone uses GitHub

Skip this skill when:
  • User gave you the API/docs URL directly — just read it
  • The project publishes a real pre-rendered site (curl bytes diverge per URL) — docs win
  • The question is purely conceptual, not config/behavior-coupled

## The four-stage ladder

Run stages sequentially; stop as soon as one yields a confident answer.

### Stage 1 — sitemap + robots discovery (~10s)

Many static docs sites (Docusaurus, MkDocs, Sphinx) keep a sitemap at a known path even when SPA routes return the same shell HTML. Sitemap URLs give you the **real canonical paths** the build emitted.

```
curl -sL --max-time 20 https://<docs-host>/sitemap.xml | head -c 4000
# Also try /sitemap_index.xml, /robots.txt (less informative but cheap)
```

Pattern to spot: every doc sub-URL returns byte-identical HTML (~10KB shell) but sitemap.xml returns real, distinct URLs. That confirms SPA hydration; fall through.

Output: a list of real doc URLs to either fetch or extract topics from.

### Stage 2 — raw.githubusercontent.com / gitlab direct probing (~30s)

Skip the GitHub REST API entirely on unauth cold start — the unauth quota is ~60 req/h and **stalks hard on rate limits** (HTTP 429) even after retries. raw.githubusercontent.com has no such limit for small reads.

```
# Probe a path-list in one shot; just want status codes.
URLS=(
  README.md CONTRIBUTING.md LICENSE
  docs/<topic>.md docs/<topic>.mdx
  src/<pkg>/config.py src/<pkg>/cli.py
  src/<pkg>/constants.py
)
for f in "${URLS[@]}"; do
  curl -sL --max-time 15 -o /tmp/p.bin -w "%{http_code}  %{size_download}  $f\n" \
    "https://raw.githubusercontent.com/<owner>/<repo>/main/$f"
done
```

Discovery rule: **probe packages before paths**. If `src/<pkg_a>/` returns 404, try `src/<pkg_b>/` and `lib/<pkg_b>/`. The first hit usually exposes the rest of the layout (the rest of canonical names live in the same tree).

### Stage 3 — targeted grep on schema / default-config files

Once you've landed two or three files from Stage 2 (config.py + __init__.py + one CLI module is the sweet spot), do a single multi-file grep for the keyword the user asked about, **plus its casing variants and underscore/space variants**, plus related siblings:

  • "working directory" / "workdir" / "cwd" / "chdir"
  • AGENTS.md / CLAUDE.md / .cursorrules — agent-rule file conventions
  • "DEFAULT_CONFIG" / "DEFAULT_SETTINGS" / "deprecated"

```
# Pattern: search_files with output_mode=content across all landed files.
# Use case-insensitive regex with alternation. Limit 200.
```

Why siblings: in real codebases the canonical config key usually lives next to its deprecated-env-var shim, default-value lookup, validation surface, and `hermes config show` display string all in the same file. Catching one pulls the rest.

### Stage 4 — read the surrounding lines with offsets

The named matches rarely give you full context. For each pinned hit, read_file with offset+limit to grab the declaring dict, the validator, and the migration/deprecation helper. Three pulls usually triangulate the answer:

  1. The DEFAULT_CONFIG entry — what the user sees if they configure nothing
  2. The validator/normalizer — what values are accepted and what causes errors
  3. The deprecation/migration helper — when an old env var maps to the new key

## Pitfalls

  **Don't delegate this to a subagent on cold start.** Background subagents will burn through GitHub's anonymous REST quota (60 req/h) in a single research task and end up returning nothing useful. The whole four-stage ladder above is ~30 individual curl calls — well within daily anonymous quota for raw.githubusercontent.com, but enough to wreck the REST API budget. Run it inline.

  **Don't trust SPA-shell HTML byte counts as a "404".** Many Docusaurus/MkDocs deployments return status 200 with the same shell HTML for every route because the SPA hasn't hydrated yet. curl will happily show you the chrome and hide the content. Confirm availability via sitemap.xml or by checking if `__NEXT_DATA__` / Docusaurus root mounts are present; otherwise skip directly to raw.githubusercontent.com.

  **Don't probe every obvious docs path one-by-one.** Bundle a path-list with status-code printing so you can sort by 200/404 in one shell pass — saves 5-10x time over single-file checks.

  **Don't anchor on the first hit.** A config key often has a *display layer* (CLI friendly show-string), a *config layer* (DEFAULT_CONFIG dict), a *validator* (special-value set + path check), a *migration/shim* (deprecated-env mapping), and a *tool layer* (the gating logic at consumer code). Stage 4 typically requires reading 2-3 of these for a complete answer.

  **Citing line numbers matters.** A correct answer in this skill looks like `config.py line 1022: "cwd": ".",  # Use current directory` not "the docs say the default is the current directory". If you can't pin a line, go back to Stage 3.

## Verification

Before reporting back, confirm you've answered the user's four-part question when applicable:

  1. **Is there an official name?** (the canonical config key / env var)
  2. **What are defaults + special values?** (the literal string set the resolver treats as "unspecified")
  3. **Is there enforcement?** (refuses-to-start, warns, auto-creates, or no-op fallthrough)
  4. **Is there a recommended substitute or migration?** (for deprecated keys)

Cite lines from landed files in the final answer. If a verdict requires a sub-question you can't pin (e.g. "the validator lives in another file we didn't fetch"), say so — don't guess.

## Linked files

  → `references/hermes-agent-canonical-keys.md` condensed findings for NousResearch/hermes-agent — what the audit on this specific project proved, so a future re-audit doesn't start from zero.
