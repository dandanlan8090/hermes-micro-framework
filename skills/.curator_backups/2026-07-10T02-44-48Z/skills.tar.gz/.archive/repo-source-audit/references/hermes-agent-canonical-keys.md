# Hermes Agent — canonical config keys & spec answers

Condensed findings from auditing NousResearch/hermes-agent source (hermes_cli/config.py and hermes_cli/doctor.py, fetched via raw.githubusercontent.com/main/). Line numbers as of the audit on 2026-06-22.

## Working directory — answer to the canonical "how should cwd be configured" question

**Canonical config key:** `terminal.cwd` in `~/.hermes/config.yaml` (under the `terminal:` map).

**Default behavior:** `"."` (single dot). Resolves to the process cwd at agent startup. No path requirement, no validation, no enforcement. Optional in every sense — if you don't touch it, the agent uses wherever you launched from.

  Lines: hermes_cli/config.py line 1019-1022 (DEFAULT_CONFIG) +
         4597-4599 (the special-values set {".", "auto", "cwd", ""} that are
         all treated as "no explicit cwd set").

**Other special values:** the four literals `.`, `auto`, `cwd`, and `""` are all recognized as "no explicit cwd" — they don't trigger the deprecated-env warning. Anything else is an explicit path the agent uses verbatim.

**Deprecated env vars that *used to* set cwd:**

  - `TERMINAL_CWD` — still bridged from `terminal.cwd` for backward compat. Config schema env map line 5667-5694 maps `cwd: <path>` to `TERMINAL_CWD=<path>` for the gateway. Migration hint printed at line 4614-4622:
        "Move to config.yaml instead:
         terminal:\n    cwd: /your/project/path"
  - `MESSAGING_CWD` — removed entirely; gateway reads `TERMINAL_CWD` (line 3832-3833).

Detector function: `warn_deprecated_cwd_env_vars(config)` at config.py line 4581-4623. Fires at CLI startup if either env var is set in `~/.hermes/.env` without an explicit `terminal.cwd`.

## Project-rule file injection — AGENTS.md / CLAUDE.md / .hermes.md / .cursorrules

These are auto-injected into the system prompt as project context, all subject to the same truncation cap:

  Lines: hermes_cli/config.py line 1197-1203:
        "context_file_max_chars": None    # Hard cap (chars) for a single automatic
                                          # context file such as SOUL.md, AGENTS.md,
                                          # CLAUDE.md, .hermes.md, or .cursorrules
                                          # before Hermes applies head/tail truncation.
                                          # ``null`` (the default) lets the cap scale
                                          # with the model's context window (floor 20K,
                                          # ceiling 500K).

**Resolved-from directory:** the same `terminal.cwd` (the effective cwd the agent is using). There is no separate "search project root" mechanism — it's "look in cwd". Default `cwd=.` means it looks in *whichever directory the user launched from*.

**Cron-only nuance:** when `cronjob` is created with `workdir=<abs-path>`, that directory's AGENTS.md/CLAUDE.md/.cursorrules are injected for the cron run and terminal/file/code_exec tools use it as cwd. For regular CLI/gateway sessions, the equivalent directory is just whatever `terminal.cwd` resolves to.

**Boundary to ~/.hermes/:** agent-rule files are project-scoped, NOT agent-scoped. Do NOT symlink AGENTS.md / CLAUDE.md / .cursorrules from inside ~/.hermes/ expecting it to be picked up globally — the injector only walks repo cwd up to the git root. If you want agent-wide defaults the right place is `~/.hermes/SOUL.md` (persona) or `~/.hermes/memories/USER.md` (user profile), never AGENTS.md inside ~/.hermes/.

## Install method stamping

Hermes supports `docker`, `git`, `pip`, `nixos`, `homebrew`. Detection logic at config.py line 370-417 (`detect_install_method`) walks code-scoped stamp first, then legacy home-scoped stamp (with `docker` ignored unless truly containerised), then managed env, then `.git`, then falls back to `pip`. The code-scoped stamp lives at `<install tree>/.install_method` — deliberately not in `~/.hermes/` so two installs can share one data dir.

## Memory system shape (verified against agent persona file)

Three layered stores with different lifecycles:

  - `fact_store` — deep structured memory with algebraic reasoning and trust scores (Holographic Memory). User preferences, durable facts, project state. Injected every turn.
  - `memory` — declarative-facts-only notes for environment / conventions / lessons. Injected. Imperative phrasing gets re-read as directive — write as declarative ("User prefers X" not "Always do X").
  - `skills` (skill_manage) — reusable procedures. NOT memory.

Filesystem checkpoints (config.py line 1158-1195) are a separate, opt-in system — `enabled: False` default, max 20 snapshots per workdir.

## Long-term memory: SOUL.md vs USER.md vs MEMORY.md

Three "long-term memory" surfaces in Hermes Agent do NOT all live in the same directory. Mixing them up is a recurring mistake; pin the layout.

### File-vs-directory map (verified 2026-06-22 against doctor.py 1148-1192)

  | Surface           | Path                              | Who writes it                       |
  | ----------------- | --------------------------------- | ----------------------------------- |
  | Persona           | `~/.hermes/SOUL.md`               | User edits directly                 |
  | User profile      | `~/.hermes/memories/USER.md`      | Agent auto-writes after observation |
  | Memory + lessons  | `~/.hermes/memories/MEMORY.md`    | Agent auto-writes after observation |

Note the asymmetry: SOUL.md is in `~/.hermes/` directly, while USER.md and MEMORY.md live under `~/.hermes/memories/`. Treating all three as `~/.hermes/*.md` is wrong.

### Semantic boundaries

  - **SOUL.md** — agent persona: tone, voice, default behavior, "how the agent embodies itself." Edit it; you are configuring the agent.
  - **USER.md** — user-side profile: who lan is, hard requirements tied to the user. Agent writes here once preferences become stable.
  - **MEMORY.md** — environment + tools + cross-session experience. Agent writes here as it accumulates observations worth keeping beyond one session.

Boundary rule: "user wants X" goes to USER.md, NOT SOUL.md. SOUL.md is for "the agent embodies Y". Confusing them corrupts both files.

### Lifecycle / auto-creation (doctor.py 1171-1192)

  - `~/.hermes/memories/` directory is created lazily on first use.
  - `MEMORY.md` is created the first time the agent writes a memory.
  - `USER.md` is created the first time the agent writes a user profile.
  - A `MEMORY.md.lock` (0-byte sibling file) guards concurrent writes; if you see it stuck, clear it manually. Don't delete a non-stuck lock.
  - The doctor check prints `will be created when the agent first writes a memory` for either file under the "not created yet" branch — that text is informational, not an error.

### Holographic Memory init triggers MEMORY.md

Initializing Holographic Memory (`fact_store`) and adding a few facts routinely causes the agent to write MEMORY.md as it stores its first seed observations. On a POSIX default-profile install, that file is the agent's work, not yours — do not pre-author it. If the path `~/.hermes/memories/MEMORY.md` exists after a session that initialized Holographic Memory, that is expected and correct.

### Why this matters for audits

Future audits that ask "where is the user's preferences file" or "where is the agent's persona file" without re-checking will answer `~/.hermes/USER.md` and `~/.hermes/SOUL.md` — wrong. Always re-pin the path against doctor.py 1148-1186 in any re-audit.

## Other canonical claims worth pocketing

  - `hermes config show` displays `Working dir:  <terminal.cwd>` at line 6603 — this is the one-line wall to grep for when verifying the user's actual cwd setting.
  - `checkpoints` config has per-workdir scoping (line 1170, 1185) — orphan cleanup walks the workdir map.
  - Context file injection is unconditional on cwd presence — if cwd exists but `.cursorrules` doesn't, no error, just nothing extra injected.

## Re-deriving these answers in a future audit

If the line numbers above drift (repo evolves), re-run `repo-source-audit` against the same hermes_cli/config.py. The five landmark search hits are stable:

  1. The DEFAULT_CONFIG `terminal:` map → confirms cwd key name + default
  2. `warn_deprecated_cwd_env_vars` → confirms migration story + special value set
  3. `context_file_max_chars` comment → confirms which project files auto-inject
  4. `hermes config show` "Working dir" line → confirms user-visible display
  5. doctor.py `memories_dir = hermes_home / "memories"` → confirms USER/MEMORY path

If all five still hit, the answer is unchanged. If hits move or vanish, the schema has been refactored — drop back to Stage 3 of the umbrella skill.
