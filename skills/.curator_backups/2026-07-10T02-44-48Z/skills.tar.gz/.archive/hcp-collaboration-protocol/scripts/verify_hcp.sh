#!/bin/bash
# HCP 一键验证脚本
# 用法：./verify_hcp.sh

set -e

HERMES_HOME="${HERMES_HOME:-$HOME/.hermes}"
SOCKET_PATH="$HERMES_HOME/hcp.sock"
TOKEN_PATH="$HERMES_HOME/hcp.token"
LOG_FILE="$HERMES_HOME/hcp_server.log"

echo "=============================================="
echo "HCP Status Check"
echo "=============================================="

# 1. 检查 Server 进程
echo -n "HCP Server: "
if ps aux | grep -q "[h]cp_server.py"; then
    PID=$(pgrep -f "hcp_server.py" | head -1)
    echo "✅ Running (PID $PID)"
else
    echo "❌ NOT RUNNING"
    exit 1
fi

# 2. 检查 Socket
echo -n "Unix Socket: "
if [ -S "$SOCKET_PATH" ]; then
    PERMS=$(stat -c "%a" "$SOCKET_PATH" 2>/dev/null || stat -f "%Lp" "$SOCKET_PATH" 2>/dev/null)
    echo "✅ Exists (permissions: $PERMS)"
else
    echo "❌ NOT FOUND"
    exit 1
fi

# 3. 检查 Token
echo -n "Token: "
if [ -f "$TOKEN_PATH" ]; then
    TOKEN=$(cat "$TOKEN_PATH" | head -c 16)
    echo "✅ Exists ($TOKEN...)"
else
    echo "❌ NOT FOUND"
    exit 1
fi

# 4. 检查日志
echo -n "Server Log: "
if [ -f "$LOG_FILE" ]; then
    LINES=$(wc -l < "$LOG_FILE")
    echo "✅ Exists ($LINES lines)"
else
    echo "❌ NOT FOUND"
fi

# 5. 检查 Watchdog
echo -n "Watchdog: "
if ps aux | grep -q "[w]atchdog.py"; then
    PID=$(pgrep -f "watchdog.py" | head -1)
    echo "✅ Running (PID $PID)"
else
    echo "⚠️  NOT RUNNING"
fi

echo ""
echo "=============================================="
echo "Quick Heartbeat Test"
echo "=============================================="
SESSION_ID="verify_$(date +%s)"
echo "Session ID: $SESSION_ID"

python3 - "$SESSION_ID" "$SOCKET_PATH" "$TOKEN_PATH" << 'PYEOF'
import sys, socket, json, time
from pathlib import Path

session_id = sys.argv[1]
socket_path = Path(sys.argv[2])
token_path = Path(sys.argv[3])

with open(token_path, "r") as f:
    token = f.read().strip()

message = {
    "jsonrpc": "2.0", "id": 1, "method": "heartbeat",
    "params": {
        "session_id": session_id, "status": "running",
        "step": "verify", "progress_percent": 0, "sequence_num": 1,
        "token": token, "timestamp": time.time()
    }
}

sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
sock.connect(str(socket_path))
sock.sendall((json.dumps(message) + "\n").encode('utf-8'))

response_data = b""
while True:
    chunk = sock.recv(4096)
    if not chunk: break
    response_data += chunk
    if b"\n" in response_data: break
sock.close()

response = json.loads(response_data.decode('utf-8'))
if "result" in response and response["result"].get("ack"):
    print(f"✅ Heartbeat OK: {json.dumps(response['result'], indent=2)}")
    sys.exit(0)
else:
    print(f"❌ FAILED: {json.dumps(response, indent=2)}")
    sys.exit(1)
PYEOF

echo ""
echo "=============================================="
echo "✅ HCP is operational"
echo "=============================================="