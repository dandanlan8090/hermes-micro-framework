---
name: linux-dpkg-repair
description: Diagnose and recover broken dpkg/apt state on Debian-family systems (Ubuntu
  / Debian / Armbian). Triggers when `apt-get` fails with half-configured / unparseable-status
  / lock-permission errors, when `dpkg -s <pkg>` returns "Cannot parse", when /var/lib/dpkg/status
  has duplicate Package sections, or when postinst hooks (install-info, man-db, modules)
  loop-fail. Use when user says "apt 装不上"/"dpkg 状态坏了"/"半配置包修复" or returns to a machine
  after a previous big batch install.
metadata:
  hermes:
    tags:
      trigger:
      - linux
      - dpkg
      - apt
      - 包管理
      - 修复
      - ubuntu
      - debian
      disable:
      - cli_only
      - read_only
---
 Linux dpkg Repair — 烂尾 apt/dpkg 状态恢复

把 `apt-get install` / `dpkg --configure` 跑不起来的 Debian-family 系统,掰回到「能正常装包」的状态。一律不动用户数据,只动 dpkg metadata + 包管理器缓存。

## When to Use

- 跑 `apt-get install -f` 卡在某个包的 postinst hook 死循环(典型:install-info / man-db / initramfs-tools)
- `dpkg -s <pkg>` 报 `error: parsing file '/var/lib/dpkg/status' near line N` 或 `duplicate value for 'Package' field` 或 `Config-Version field present for package with inappropriate 'Status' field`
- `dpkg -l | grep '^.[ih][FU]'` 出现 iF / iU / hU 包, define `dpkg-query` 反复报错
- `apt-get install` 报 `0 upgraded, 0 newly installed` 但包实际没装上(即 status 已 ok 但文件不全,常见于 p7zip-full 类上游换包名)
- 用户说「上次补充装的依赖没完」/「apt 装不上」「半配置」「iF 残留」

**Not for**: 纯镜像源问题(改 sources.list 就行,不属 dpkg repair)、dpkg 网络代理问题、apt-key 类密钥问题。

## 决策树:先定位再动手

跑以下命令 30 秒内就能拿到故障图谱:

```bash
# 1. 状态总览
dpkg -l | awk '/^.[ih][FU]/ {print $1, $2, $3}'
echo "半配置包数: $(dpkg -l | grep -cE '^.[ih][FU]')"

# 2. status 文件健康度
dpkg-query -W -f='${Package} ${Status}\n' install-info 2>&1 | head -3
# 报错则 dump 故障段:
awk '/^Package: install-info$/,/^$/' /var/lib/dpkg/status

# 3. 是否在跑锁
pgrep -af "apt-get install|dpkg --configure"
ls -la /var/lib/dpkg/lock-frontend /var/lib/apt/lists/lock 2>/dev/null

# 4. postinst hook 现场 (重点是 install-info / man-db / update-initramfs)
sudo /usr/sbin/update-info-dir 2>&1   # 看是不是 'Not a directory: export.' 这个特定 bug
```

## 修复路径 (选最便宜的)

按代价升序排列,严格从 ① 开始,做了再决定要不要继续 ② ③:

### ① 协议层面修复 — `dpkg-reconfigure` / `apt install -f`

适合 postinst 半配置 (`iF` / `hF`) 但 status 文件 base 正常的情况:

```bash
sudo dpkg --configure -a                              # 跑完历史遗留 hook
sudo DEBIAN_FRONTEND=noninteractive apt-get install -f -y --no-install-recommends
sudo apt-get autoremove --purge                        # 清掉前批不再依赖的旧内核之类
```

如果 `dpkg --configure <pkg>` 反复同一行报错:**记下报错文本 → 进 ②**。

### ② 锁定坏的 hook,让该包跳过 configure

不能跳过 `dpkg --configure`。**正确做法**:把 postinst 文件改名或后置空,保留 postrm 完整:

```bash
# 拿 install-info 7.2 的 /usr/sbin/update-info-dir 上游 bug 举例
sudo cp /var/lib/dpkg/info/<pkg>.postinst /var/lib/dpkg/info/<pkg>.postinst.bak
sudo bash -c 'echo "#!/bin/sh" > /var/lib/dpkg/info/<pkg>.postinst'
sudo bash -c 'echo "exit 0" >> /var/lib/dpkg/info/<pkg>.postinst'
sudo chmod 755 /var/lib/dpkg/info/<pkg>.postinst
sudo dpkg --configure <pkg>                           # 现在静默通过
# 之后用 apt-marker hold 防后续触发:
echo "<pkg> hold" | sudo dpkg --set-selections
```

⚠️ 严禁做的两件事:
- 全 `rm -rf /var/lib/dpkg/info/<pkg>.*` — 会让 dpkg 不知道包存在
- 把 postrm 也一起改名 — 卸载时 dpkg 会显著不对劲

### ③ 修 `/var/lib/dpkg/status` 文件本身

只有当 status 文件真的被手工改坏或 sed-surgery 漏字段时才走这条。**具体规则**:

1. 先所有备份:
   - `/var/lib/dpkg/status-old`  — 上一次 dpkg 成功 configure 后的快照
   - `/var/backups/dpkg.status.0` — dpkg 周期备份
   - `/var/lib/dpkg/status.bak`  — 之前手动备份
   任意一份能 parse,就 `sudo cp <good> /var/lib/dpkg/status`。

2. 三个最常见的 sed-surgery 漏坑(逐一查):

   | 症状 | 修法 |
   |---|---|
   | `duplicate value for 'Package' field` | 保留字段最多的那个 section,删空壳 section |
   | `Config-Version field present for inappropriate 'Status' field` | `install ok installed` 时必须删 Config-Version 行;半配置状态才允许留 Config-Version |
   | 某 section 内容被截断(末尾没空行) | 在那个 section 末尾补 `\n\n` |

3. 安全批改模板(用 Python 一次性扫所有 section,禁止 sed 流式处理):
   ```python
   import re
   t = open('/var/lib/dpkg/status').read()
   # 1) 去重 Package 行
   t = re.sub(r'(^Package: (\S+)\n)(?=Package: \2\n)', '', t, flags=re.M)
   # 2) 配置 OK 状态去 Config-Version
   def fix(m):
       head = m.group(1); body = m.group(2)
       lines = body.splitlines()
       if any(l.startswith('Status: install ok installed') for l in lines):
           lines = [l for l in lines if not l.startswith('Config-Version:')]
       return head + '\n'.join(lines) + '\n'
   t = re.sub(r'^(Package: \S+\n)((?:.|\n)*?)(?=^Package:|\Z)', fix, t, flags=re.M)
   open('/tmp/dl-status-new', 'w').write(t)
   sudo cp /tmp/dl-status-new /var/lib/dpkg/status
   ```

### ④ 不要做的事

- 不要 `chattr +i /var/lib/dpkg/lock*` — 只要不是要 freeze,就把 dpkg 锁文件 read-only 之后,sudo 都会变 `Operation not permitted`,解除也得 root。先 `chattr -i` 再走。
- 不要被 `chattr -i` 阻拦时轮回 `chattr -R` 之类。状态可能转到 fs 损坏,从备份恢复就行。
- 不要把 `apt-cache policy <pkg>` 报 `Candidate: (none)` 等同于装包失败 —— 优先查上游是否换了包名(参考 ## Pitfall P4)。

## Pitfalls

### P1: install-info 7.2 + /etc/environment 含 `export ...` = dpkg 永远跑不到 ok

**根因**:Ubuntu 26.04 + Debian 这次 install-info 7.2 的 `/usr/sbin/update-info-dir` 在读 `/etc/environment` 时:
```sh
while read -r env
do
  env="${env%%#*}"
  if [ -n "$env" ]; then
    set -- $env
    case "$1" in *=*) eval "export $1 2>/dev/null" ;; esac
  fi
done
```
遇到 `export http_proxy=...` 行, `set -- $env` 后 `$1='export'` 不匹配 `*=*`,本应被 case 跳过。但循环结束后 `$1` 残留为 `export`, 落到下游:
```sh
if [ -n "$1" ]; then INFODIR="$1"; fi
```
`INFODIR` 被覆写为 `export`, 接着 `if [ ! -d "$INFODIR" ]` 输出 `Not a directory: export.`,dpkg-align install-info postinst 失败。

**Safe fix**(不破坏 sudo 拦截 友好的方式优先):
```bash
# 1) 先把 update-info-dir bug 段合理修补:把 /etc/environment 中的 `export `
#    前缀全部剥掉,改写 `KEY=VAL` 单行格式(不需 sudo 的批量安装场景,
#    主机有不可一瞬间动 /etc/environment,所以走 ②)
sudo tee /etc/environment <<'EOF'
PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin"
http_proxy=http://example.com:7894
https_proxy=http://example.com:7894
no_proxy=localhost,127.0.0.1,::1,.local
EOF
# 2) 再重新 dpkg-configure
sudo dpkg --configure install-info
```

如不是 proxy /etc/environment 格式问题,走 ② 路径(空 postinst + hold)最可靠。

### P2: apt-get install 报 `0 upgraded, 0 newly installed` ≠ 装包成功

可恶的 上游改名场景。例:`p7zip-full` 在 Ubuntu 26.04 仓库里被换成 `7zip`(`apt-cache search p7zip` 只剩 `7zip`),命名字换但实际内容更精简。**判定 + 修复**:

```bash
apt-cache policy <原package名>   # Candidate: (none) = 上游换了名字
apt-cache search '<原package名>' # 看有没有 <原package名>/<变体>
sudo apt-get install -y <新包名> # 装新的
```

已知 26.04 改名列表(正在进行中):
| 旧包 | 新包 |
|---|---|
| p7zip-full | 7zip + 7zip-doc |
| wkhtmltopdf (仓库删除) | 无上游替换:拉二进制或编考 |

### P3: double-handling /var/lib/dpkg/status

Sed 流式处理比手工易出错。即使一个简单的 `sed -i '/Install-info:/{N;...}'`,也可能:
1. 调 Pattern 误中
2. 改完 'Config-Version' 与 'Status' 不配套 → dpkg-query parsing error
3. 多个 sed 叠加后产生 duplicate Package section

**Lesson**: status 是 dpkg database,不是配置文件。改前先备份;改后验 parse:
```bash
sudo cp -p /var/lib/dpkg/status /tmp/status.bak
# ... 改 ...
sudo cp /tmp/dl-status-new /var/lib/dpkg/status
for pkg in $(dpkg --get-selections | awk '{print $1}'); do
  dpkg-query -W -f='${Package} ${Status}\n' "$pkg" >/dev/null 2>&1 || echo "BROKE: $pkg"
done | head
```

### P4: 不要 `sudo cp /etc/environment.bak /etc/environment` 后以为完事

/etc/environment 被 Tirith/Hermes 安全层拦住是期间的，不是说不能改。改后该重新登入终端让子进程拿到新 env;需要 sudo 时传 env 透受另一半。

### P5: 装包后 `dpkg -l` 报 half-configured fallout,但 trigger 未完成 hook

例:`install-info` postinst 跑但中间 `update-info-dir` 报错 → dpkg 返回 1 → mark 为 half-configured。后续任何 apt 都会卡。这里需要走 ① + ②。

### P6: `apt-get update` 后 `Candidate` 仍 none

不是 mirror 问题,是 phase 没过 universe。 确认 sources.list.d/* 列表里 该 universe 组件 启用。

## 验证

**装任何包能跑**:
```bash
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends hello 2>&1 | tail -5
hello   # 应回 'Hello, world!'
```

**半配置包清零**:
```bash
dpkg -l | awk '/^.[ih][FU]/ {print $2}' | head
# 预期:空输出
```

**install-info 能跑过**:
```bash
sudo /usr/sbin/update-info-dir 2>&1     # 应空输出,exit 0
sudo dpkg --configure -a 2>&1 | tail -3  # 应 'Setting up ...' ,无 err
```

**status 库可 parse**:
```bash
for pkg in $(dpkg --get-selections | awk '{print $1}' | head -200); do
  dpkg-query -W -f='' "$pkg" >/dev/null 2>&1 || echo "BROKE: $pkg"
done | wc -l
# 预期: 0
```

## Cross-references

- AGENTS.md §3 (verification before completion) — 30 秒决策树跑完才有资格接着动
- coding-and-research-style §6 (section discipline) — 修复路径 + pitfalls 表格都有
- hermes-bootstrap P1 — 以下 sudo 塊走 sudoers NOPASSWD,不走 S$ 注入;但在改 /etc/environment 这种是 例外场景 (拉互为代理),仍然走 prompt 6
- 详细 install-info bug 调查 + 修法序列在 `references/install-info-update-info-dir-bug.md`
- 状态文件 sed-surgery 的安全模板 + 测试包 · `scripts/status-file-sanitizer.py`

## Linked files

- `references/install-info-update-info-dir-bug.md` — install-info 7.2 + update-info-dir + /etc/environment 交互,完整诊断 + 修法序列,已验证可复现
- `scripts/status-file-sanitizer.py` — 安全的 status 文件 sectoin dedup + Config-Version 同步清理模板