# Trending / Aggregator 站点取数参考

存的是从 2026-06-23 那个会话拿到的实测数据,以后再刮类似站点直接对表。

## 1. 站点形态决定取法(先判定,再选路径)

| 站点 | 形态 | 数据入口 | 取数成本 |
|---|---|---|---|
| github.com/trending?since=weekly | SSR (服务端渲染) | HTML 内嵌 `<article class="Box-row">` 列表 | curl → 正则 1 步 |
| hotgit.org/repos?category=star_weekly | SPA (前端渲染) | HTML 内裸 nav, 真数据走 hydration JSON 或内部 API | curl = 空, 要打 hydration 或换源 |
| atomgit.com mirrors | SSR + JSON 双 | 看具体路径 | 中 |
| star-history.com | SPA (Recharts 客户端) | SVG 渲染, 无文本清单 | 不要试着 grep, 直接当图表看 |

好用的判定三件套:
```bash
curl -sL --max-time 20 -A 'Mozilla/5.0' "<URL>" -o /tmp/probe.html
echo "size: $(wc -c < /tmp/probe.html)"             # SSR 通常 >50KB, SPA 通常 <50KB
grep -c '<article\|Box-row\|/repo/[a-zA-Z]' /tmp/probe.html   # 计数, 0 = SPA
grep -c '__NEXT_DATA__\|__INITIAL_STATE__\|window\.__' /tmp/probe.html  # hydration 锚
```
任一条命中足够判定形态。

## 2. GitHub Trending — 推荐走法(SSR, 稳定)

完整提取一周榜的脚本骨架(实测产物每周 60-80KB,18-25 个 article):
```bash
curl -sL --max-time 20 -A 'Mozilla/5.0' \
  'https://github.com/trending?since=weekly' \
  -o /tmp/gh-trending-weekly.html

python3 - <<'PY'
import re
html = open('/tmp/gh-trending-weekly.html').read()
arts = re.findall(r'<article[^>]*class="Box-row[^"]*"[^>]*>(.*?)</article>', html, re.S)
for a in arts:
    repo = re.search(r'<h2[^>]*>\s*<a[^>]+href="/([^"]+)"', a)
    desc = re.search(r'<p class="col-9[^"]*">\s*(.*?)\s*</p>', a, re.S)
    lang = re.search(r'itemprop="programmingLanguage">([^<]+)</span>', a)
    if repo:
        r = repo.group(1)
        d = re.sub(r'<[^>]+>', '', desc.group(1)).strip() if desc else ''
        l = lang.group(1).strip() if lang else ''
        print(f"{r} | {l} | {d[:140]}")
PY
```

实测样品(2026-06-23 周榜前 18,摘录):
```
DeusData/codebase-memory-mcp | C | High-performance code intelligence MCP server…
calesthio/OpenMontage | Python | World's first open-source, agentic video production…
Panniantong/Agent-Reach | Python | Give your AI agent eyes to see the entire internet…
addyosmani/agent-skills | Shell | Production-grade engineering skills for AI coding agents…
NVIDIA/SkillSpector | Python | Security scanner for AI agent skills…
github/spec-kit | (n/a, 主榜未出现在扣上面) | GitHub official spec-kit workflow…
```
(完整 18 条在 /tmp/gh-trending-weekly.html,本次会话产物,核对用)

## 3. hotgit.org — 为什么不值得裸 curl

- WHOIS: 注册 2026-03-29, Cloudflare 后面挂的二手聚合站, <3 个月
- HTML 体积: 35-40KB(SSR 周榜 60KB+, 这是个 spa)
- HTML 内容: 整个文件只有 `<a>Star 榜/Fork榜/日增/周增/月增/重置/页码</a>` 这种 nav, 没有任何 `/owner/repo` 形式 href
- 真数据需要走 hydration(我没在 HTML 里找 `__NEXT_DATA__`, 试了一次 css-only 路径, 不通; 推测它走 runtime fetch + 客户端 store)
- 结论: **不用再裸 curl hotgit**, 直接走 GitHub Trending SSR, 数据实时度差 ≤ 24 小时, 可忽略

如果一定要 hotgit 的 sitemap/category 排序数据,配 firecrawl 走(它有 headless render):
```bash
# 见 firecrawl skill, 这里不重复命令
```

## 4. 反向教训 / 容易反复踩的坑

- 不要被 "周榜" 这个词的权威感带偏 — 很多站点都是聚合 GitHub Trending 自己重排, **唯一源头是 github.com/trending**。判定 SPA 时 web-of-trust 顺序: github.com > atomgit/snowraked 镜像 > 老牌聚合(hotgit 类) > 二三线。 老牌 ≠ 真, 查 whios 才知道。
- 取 GitHub Trending 时记得 -A 'Mozilla/5.0', 不带 UA 部分时段会返回 desktop shell
- 不要把产品页 article body 当数据源 — 那是详情页, 列表数据只在 trending/ 页
- 跨站点对比时, 体积差常常就告诉你形态差: 35KB vs 600KB 这种就是 SPA / SSR
- 当你拿不到列表数据时, **立刻转源** 而非花更多 round-trip 撞 SPA, 单次会话里撞 1 次是信号, 撞 2 次 = 浪费时间

## 5. 周榜类任务的「固定流程」套路

1. 先 milestone: 问用户「看榜单, 还是看具体项目?」如果只是榜单,直接走 GitHub Trending; 如果是具体项目,走 fetch GitHub repo 路径(CLAUDE.md 那条)
2. 探测目标站点: wc -c + grep -c + grep hydration 三件套,2 秒内判定 SPA/SSR
3. SSR 落地: curl → re.findall 提 article → 1-2 个 print 即出
4. SPA 落地: 转源优先, firecrawl 第二, 放弃第三; 三选一用足前不升级
5. 落盘 /tmp/<site>-<period>.html, 会话产物可直接 read_file 复检
