---
name: apple-integrations
description: "Manage Apple ecosystem from the terminal on macOS — Notes, Reminders, Find My (AirTags/devices), and iMessage/SMS. Class-level guidance for the four Apple CLI integrations, with one entry point instead of four narrow skills."
category: apple
version: 1.0.0
author: Hermes Agent (umbrella consolidation)
license: MIT
platforms: [macos]
metadata:
  hermes:
    tags: [Apple, macOS, Notes, Reminders, FindMy, AirTag, iMessage, SMS, Terminal-Automation]
    related_skills: [obsidian, macos-computer-use]
    absorbed_into_umbrella: [apple-notes, apple-reminders, findmy, imessage]
---

# Apple Integrations — Terminal Control of the Apple Ecosystem

One class-level entry point for driving Apple's first-party apps from the terminal on macOS. All four integrations are macOS-only and assume the relevant app is signed into the user's iCloud account. Searching this skill replaces searching four separate narrow skills.

## Subsection Map

| What you need to do | Go to |
|---|---|
| Create / search / edit Apple Notes | [1. Notes](#1-notes) |
| Add / list / complete Reminders | [2. Reminders](#2-reminders) |
| Track devices / AirTags via Find My | [3. Find My](#3-find-my) |
| Read / send iMessage or SMS | [4. iMessage](#4-imessage) |

---

## 1. Notes

Use `memo` to manage Apple Notes directly from the terminal. Notes sync across all Apple devices via iCloud.

**Prerequisites**
- macOS with Notes.app
- Install: `brew tap antoniorodr/memo && brew install antoniorodr/memo/memo`
- Grant Automation access to Notes.app when prompted (System Settings → Privacy → Automation)

**When to use**: create, view, or search Apple Notes.
**Related**: pairs well with `obsidian` for cross-system note search.

---

## 2. Reminders

Use `remindctl` to manage Apple Reminders directly from the terminal. Tasks sync across all Apple devices via iCloud.

**Prerequisites**
- macOS with Reminders.app
- Install: `brew install steipete/tap/remindctl`
- Grant Reminders permission when prompted
- Check: `remindctl status` / Request: `remindctl authorize`

**When to use**: add, list, or complete reminders ("reminder" / "Reminders app").

---

## 3. Find My

Track Apple devices and AirTags via FindMy.app on macOS. Apple provides no CLI for Find My, so this skill uses AppleScript to open the app and screen capture to read device locations.

**Prerequisites**
- macOS with Find My app and iCloud signed in
- Devices / AirTags already registered in Find My
- Screen Recording permission for terminal (System Settings → Privacy → Screen Recording)
- Optional but recommended: `brew install steipete/tap/peekaboo` for better UI automation

**When to use**: locate a registered device or AirTag. Because it relies on AppleScript + screen capture, treat returned locations as read-only and verify before acting.

---

## 4. iMessage

Use `imsg` to read and send iMessage/SMS via macOS Messages.app.

**Prerequisites**
- macOS with Messages.app signed in
- Install: `brew install steipete/tap/imsg`
- Grant Full Disk Access for terminal (System Settings → Privacy → Full Disk Access)
- Grant Automation permission for Messages.app when prompted

**When to use**: send or read an iMessage / text message.

---

## Cross-cutting notes

- All four require macOS + the corresponding Apple app signed into iCloud. Fail fast with a clear "requires macOS + <App>" message if absent.
- Grant the listed System Settings permissions (Automation / Screen Recording / Full Disk Access) — without them the CLIs error or silently no-op.
- None of these four touches user data destructively; keep it that way.
