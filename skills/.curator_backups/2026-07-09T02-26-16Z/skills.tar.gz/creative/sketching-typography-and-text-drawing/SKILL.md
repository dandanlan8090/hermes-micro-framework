---
name: sketching-typography-and-text-drawing
description: "Generate standalone sketch, diagram, chart, ASCII art/video, and text/typographic HTML/Markdown artifacts — class-level guidance for sketch-to-file deliverables."
version: 1.0.0
author: Hermes Agent (umbrella consolidation)
license: MIT
metadata:
  hermes:
    tags: [Sketch, ASCII-Art, ASCII-Video, Typography, Text-Layout, Drawing, Generative-Art, Diagrams]
    related_skills: [visual-design, architecture-diagram, pretex]
---

# Sketching, Typography & Text Drawing — Class-Level Guidance

This umbrella covers text-as-visual and ASCII/character-based deliverables:
quick HTML sketches, Markdown+CSS diagrams, ASCII art, ASCII video, and
text-layout / kinetic-typography browser demos.

## Subsection Map

| What you need to do | Go to |
|---|---|
| Produce an HTML/CSS sketch, chart, or wireframe | [HTML/CSS Sketches](#1-htmlcss-sketches) |
| Make a diagram in Markdown / Mermaid / chart renderer | [Markdown Diagrams & Charts](#2-markdown-diagrams--charts) |
| Generate ASCII art (banner, image, diagram) | [ASCII Art](#3-ascii-art) |
| Convert video or audio to colored ASCII MP4/GIF | [ASCII Video](#4-ascii-video) |
| Build text-flow / kinetic typography browser demos | [Kinetic Typography & Pretext Demos](#5-kinetic-typography--pretext-demos) |

## 1. HTML/CSS Sketches

See absorbed skill `sketch` for:
- Quick HTML mockups: 2-3 design variants you can compare
- Wireframe-utilitarian to visual-complete spectrum
- Output as self-contained `.html` files with embedded CSS

## 2. Markdown Diagrams & Charts

When producing diagram captions, flow charts, sequence diagrams, or simple
infographics in Markdown:

- Use **Mermaid** when the output format is Markdown/HTML and you need a
  renderer-understood diagram: `graph TD` for flows, `journey` for user flows,
  `sequenceDiagram` for call sequences, `classDiagram` for structure.
- Use **ASCII-Draw ASCII-viz** principles (see ASCII Art section) when the
  output must work in any terminal or plain text.
- Use **visual-design umbrella Excalidraw / SVG arches** (sections under
  `creative/visual-design/`) when the artifact requires layout beyond clean
  Markdown diagrams.

## 3. ASCII Art

See absorbed skill `ascii-art` for:
- Python library-based ASCII art: `pyfiglet`, `cowsay`, `boxes`, `image-to-ascii`
- Formatting: banner text, boxed text, label art
- Suitable for terminal output, docs, and markdown decoration

## 4. ASCII Video

See absorbed skill `ascii-video` for:
- Converting video/audio to colored ASCII MP4 / GIF output
- Full pipeline: source → preprocess → ascii-frame render → encode
- Suitable for terminal playback or embedding in readme/docs

## 5. Kinetic Typography & Pretext Demos

See absorbed skill `pretext` (under `creative/`, before archive) for:
- DOM-free text measurement and layout via `@chenglou/pretext`
- Kinetic typography, text-flow-around-obstacles, text-as-geometry games
- Single-file HTML demos with Canvas 2D rendering

## Boundary

- For **photo-real or style-based image generation**, use `media/media-creation-and-audio/`
  (ComfyUI / generative image skills).
- For **real-time audio-reactive motion graphics**, use `touchdesigner-mcp`.
- For **royalty-ready infographic layouts** (Chinese / poster / data-explainer),
  see `visual-design` subsection [Info-Graphics](#3-info-graphics-baoyu).
