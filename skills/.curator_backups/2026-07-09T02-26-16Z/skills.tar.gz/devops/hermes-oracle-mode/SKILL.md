---
name: hermes-oracle-mode
description: "Use when the user explicitly requests 主脑模式, Oracle Mode, 主脑调度, or multi-agent command-center execution. Defines Hermes-fn as the orchestrator that plans, dispatches subagents, fixes blocked agents first, independently verifies results, and delivers one validated report."
version: 1.0.0
author: Hermes-fn
license: MIT
platforms: [linux, macos]
metadata:
  hermes:
    tags:
      trigger:
        - 主脑模式
        - 启用主脑模式
        - 使用主脑模式
        - Oracle Mode
        - mastermind mode
        - 多 Agent 调度
        - multi-agent orchestration
        - 子 agent 验证
        - OpenClaw OpenCode 协作
      disable:
        - 普通单步问答
        - 无需多 agent 的简单查询
        - pure text answer
        - simple one-shot command
        - 单文件小改动且用户未要求主脑模式
    skill_type: workflow
    priority: highest
    related_skills: [agent-collaboration-workflow, hermes-verification-workflow, plan]
---

# Hermes Oracle Mode

## Overview

Hermes Oracle Mode is the class-level workflow for using Hermes-fn as a command center: task decomposition, subagent dispatch, blockage repair, result verification, and final delivery.

This skill exists so `SOUL.md` stays thin. `SOUL.md` should only define identity, red lines, and the trigger rule: when the user explicitly asks for 主脑模式 or Oracle Mode, load this skill and follow it. The full workflow lives here, not in the identity file.

## When to Use

Use this skill when:
- The user explicitly says `使用主脑模式`, `启用主脑模式`, `Oracle Mode`, or equivalent wording.
- A task needs Hermes to coordinate OpenClaw, OpenCode, delegate_task, or other subagents as a unified workflow.
- The user asks for multi-agent investigation, multi-agent verification, or a command-center style execution.
- Subagent outputs must be treated as untrusted until Hermes independently verifies them.
- Blocked OpenClaw/OpenCode/subagent processes are part of the task and need repair before more dispatch.

Do not use this skill for:
- Simple text answers.
- One-shot read-only checks.
- Ordinary small edits where the user did not request 主脑模式.
- Cases where a specialized skill fully covers the task and no orchestration is needed.

## SOUL.md Placement Rule

Keep only the trigger rule in `SOUL.md`:

```markdown
## 主脑模式触发规则

当用户明确说出“使用主脑模式”“启用主脑模式”“Oracle Mode”“主脑调度”等指令时，必须先加载并执行 `hermes-oracle-mode` skill。

未加载该 skill 前，禁止进入多 Agent 派发、结果整合、验证交付流程。

主脑模式的完整流程、阻塞处理、质量验证、交付格式以 `hermes-oracle-mode` skill 为唯一来源。
```

Do not paste the full Oracle workflow into `SOUL.md` or `AGENTS.md`. That creates context bloat and makes future updates drift across files.

## Core Workflow

### 1. Task Parse

Define:
- User goal.
- Delivery artifact.
- Constraints and risks.
- Which subtasks are independent.
- Which tools or agents are appropriate.

Completion criterion: the task can be decomposed without guessing hidden requirements. If a missing decision blocks safe execution, ask one focused clarification.

### 2. Plan and Todo

Before tool-heavy work, write or update a plan and maintain a todo list.

The plan must state:
- Subtasks.
- Verification method for each subtask.
- Dispatch boundaries.
- Risk controls.
- Final report shape.

Completion criterion: every dispatched subtask has a success condition and output format.

### 3. Subagent Dispatch

Dispatch only independent work in parallel. Each child task must be self-contained:
- Goal.
- Context.
- Exact scope.
- Forbidden changes.
- Expected output format.
- Success definition.

Use `delegate_task` for bounded reasoning subtasks. Use external agents such as OpenClaw/OpenCode only when their strengths match the task and their service state is known.

Completion criterion: no child agent is missing required context, and no two children are racing over the same mutable state.

### 4. Blockage First

If any OpenClaw, OpenCode, or delegated subagent is blocked, repair the blockage before dispatching new work.

Blocked signals:
- Timeout.
- No heartbeat.
- Repeated identical errors.
- Process stuck in TUI or waiting for input.
- Parent cannot receive child completion.

Immediate sequence:
1. Identify the blocked process or session.
2. Stop or kill it safely.
3. Clean stale state if needed.
4. Shorten timeout, change transport, or switch method.
5. Retry the original task with adjusted parameters.
6. Verify the blockage is gone.

Hard rule: do not continue launching new subtasks while a known subagent blockage remains unresolved.

### 5. Result Collection

Treat every subagent report as an untrusted claim until verified.

Collect:
- Claimed changes.
- Claimed test results.
- Claimed service state.
- Claimed paths, commands, ports, versions, or URLs.
- Any blockers or uncertainty the child reported.

Completion criterion: every child output is mapped to a verification action or explicitly marked as informational.

### 6. Independent Verification

Verify with direct evidence, not self-report.

Check these classes as applicable:
- Data accuracy: compare reported CPU, memory, disk, versions, files, or counts with actual commands or reads.
- Service state: check `systemctl`, `ss`, process table, or health endpoints.
- Connection configuration: test JSON-RPC, HTTP health checks, stdio responses, or ACP/MCP handshakes.
- Logic consistency: confirm the report does not contradict itself, the timeline, or the actual system state.
- Code correctness: run focused tests, builds, linters, or reproduction commands.

Completion criterion: every material claim in the final answer is backed by a real verification result, or is explicitly labeled unverified.

### 7. Verification Decision

If all required verification passes:
- Produce the final report.

If verification fails:
- Identify the failed item.
- Decide whether it is data error, service error, config error, test-method error, or design error.
- Dispatch a correction task or fix directly.
- Repeat collection and verification.

Completion criterion: no known verification failure remains in a final positive conclusion.

### 8. Final Delivery

Deliver one concise Markdown-style report with:
- Conclusion first.
- What was done.
- Verification evidence.
- Remaining risks or blockers.
- Participating agents and verification status.

For multi-agent work, include:
- `【Hermes】`
- Assistance list.
- Verification status.
- `Generated by Hermes` plus assistant agents.

For Hermes-only work, end with:
- `only by Hermes`

## Dispatch Template

```text
Goal: one precise outcome.
Context: all relevant paths, logs, constraints, current findings.
Scope: files, services, or subsystem allowed.
Do not touch: explicit exclusions.
Success definition: exact command, state, or artifact that proves completion.
Output: concise Markdown or JSON with claims, evidence, blockers.
```

## Verification Checklist

Before final answer:
- [ ] The user explicitly requested 主脑模式 or the skill was otherwise clearly triggered.
- [ ] A plan and todo existed before heavy execution.
- [ ] Every subagent was given self-contained context.
- [ ] Blocked agents were repaired before additional dispatch.
- [ ] Subagent claims were independently verified.
- [ ] Failed verification caused correction or was clearly reported as a blocker.
- [ ] Final output is one coherent report, not fragmented notes.
- [ ] No fabricated paths, commands, service states, versions, or test results appear.

## Common Pitfalls

1. Keeping the full workflow in `SOUL.md`.
   Fix: keep only the trigger rule in `SOUL.md`; this skill is the workflow source of truth.

2. Trusting subagent self-report.
   Fix: verify data, service state, connection state, and logic directly.

3. Continuing dispatch while OpenClaw or OpenCode is stuck.
   Fix: kill, clean, shorten timeout or change method, then retry before new dispatch.

4. Overusing Oracle Mode for ordinary work.
   Fix: require an explicit trigger or a real multi-agent orchestration need.

5. Producing multiple scattered documents.
   Fix: final delivery is one report with conclusion first and evidence included.

## Related Workflows

- Use `agent-collaboration-workflow` for concrete Hermes/OpenClaw/OpenCode architecture, ACP/MCP direction, tmux wrappers, and service checks.
- Use `hermes-verification-workflow` for deeper verification patterns.
- Use `plan` before implementation-heavy Oracle runs.
