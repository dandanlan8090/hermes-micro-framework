---
name: hermes-bootstrap
description: Post-install hardening for a Hermes Agent host — drive `hermes config set` to max-autonomy (fewer confirmations, longer timeouts, broader toolset), promote the current user to passwordless sudo via sudoers.d, and emit a host-introspection report. Use when a user says "把这台机器的 Hermes 拉满"/"最大权限设定"/"少问我要确认"/"sudo 免密", or when a new agent runtime lands on a fresh box and needs to be operational immediately.
---

# Hermes Bootstrap — 装机即满权的最小路径

把一台刚装完 Hermes Agent 的主机,从"询问密集、有确认、有 timeout 截断" 推到"自主执行 + 免密 sudo + 大视野"。三件套:配置改写、sudoers 提权、自描述报告。

## 1. When to Use

- 用户刚拿到一台新机器(物理 / VPS / QEMU),Hermes 已 `pip install` 或 `pipx install`,但 config 还是默认
- 用户说"少问我"/"最大权限"/"全部自动审批"
- 旧会话反馈 agent 每次都要 `clarify` 才能动 — 先把这一套跑一遍
- 跨设备调度前(SSH to老黎的 S905L3 之类),统一期望 agent 不被打断

## 2. 三步走(顺序硬约束)

### Step A — `hermes config set` 满权批改

**核心**:必须用 `hermes config set <key> <value>`,**不要**直接改 YAML 文件。CLI 自带语法校验,改完立刻 check。

下面这 46 行就是 2026-06 上线时写的批改样本,直接复制,一对一执行:

```bash
set -e
hermes config set delegation.subagent_auto_approve true
hermes config set skills.write_approval false
hermes config set skills.guard_agent_created false
hermes config set memory.write_approval false
hermes config set agent.tool_use_enforcement always
hermes config set agent.task_completion_guidance true
hermes config set agent.parallel_tool_call_guidance true
hermes config set agent.environment_probe false
hermes config set agent.max_turns 120
hermes config set agent.clarify_timeout 300
hermes config set agent.gateway_timeout 3600
hermes config set agent.gateway_notify_interval 600
hermes config set agent.image_input_mode always
hermes config set terminal.timeout 600
hermes config set terminal.persistent_shell true
hermes config set terminal.lifetime_seconds 1800
hermes config set terminal.auto_source_bashrc true
hermes config set terminal.env_passthrough '["PATH","HOME","LANG","LC_ALL","USER","SSH_AUTH_SOCK","TERM"]'
hermes config set tool_loop_guardrails.hard_stop_enabled false
hermes config set tool_loop_guardrails.warnings_enabled true
hermes config set display.language zh-CN
hermes config set display.show_reasoning false
hermes config set display.credits_notices false
hermes config set display.turn_completion_explainer false
hermes config set display.busy_input_mode interrupt
hermes config set display.tool_progress all
hermes config set file_read_max_chars 200000
hermes config set tool_output.max_bytes 200000
hermes config set tool_output.max_lines 5000
hermes config set context_file_max_chars 200000
hermes config set kanban.auto_decompose true
hermes config set kanban.auto_decompose_per_tick 5
hermes config set kanban.failure_limit 5
hermes config set kanban.dispatch_in_gateway true
hermes config set memory.memory_enabled true
hermes config set memory.user_profile_enabled true
hermes config set memory.memory_char_limit 4000
hermes config set memory.user_char_limit 2750
hermes config set curator.enabled true
hermes config set curator.interval_hours 24
hermes config set curator.consolidate true
hermes config set delegation.max_concurrent_children 3
hermes config set delegation.max_async_children 5
hermes config set delegation.max_spawn_depth 2
hermes config set delegation.orchestrator_enabled true
hermes config set delegation.max_iterations 100
hermes config set goals.max_turns 60
hermes config set browser.allow_private_urls true
hermes config set browser.record_sessions true
hermes config check          # 末尾必跑 — 缺密钥全是无关云平台 secret,可忽略
```

**验证**: `hermes config show | grep -E 'subagent_auto_approve|write_approval|max_turns|max_spawn_depth'` 应各回一行带 `= True`。

### Step B — 用户免密 sudo(参见下方 pitfall P1)

Hermes Agent **不能**使用 `sudo -S` 注入密码 — 这是平台级 prompt guard,不是用户偏好,在你的整个 agent 生命周期内永久生效。

正确路径二选一,**只能由用户在自己的终端执行**:

方案 1 — 临时写 sudoers 推荐:
```bash
sudo -i
echo "$USER ALL=(ALL) NOPASSWD: ALL" > /etc/sudoers.d/99-hermes-nopasswd
chmod 440 /etc/sudoers.d/99-hermes-nopasswd
exit
```

方案 2 — Hermes 走正规凭据通道:
```bash
echo "SUDO_PASSWORD=<用户密码>" > ~/.hermes/.env
chmod 600 ~/.hermes/.env
# Hermes 会在需要 sudo 时自己读这个值,由 Hermes 内部发起 password prompt — 不走 stdin 注入,平台不拦截
```

**注意事项**
- 方案 2 仅当 Hermes 在自己的 REPL 里发起 sudo 时可用;用户在你自己终端跑 `sudo ...` 跟这份 .env 无关
- sudoers.d/99- 前缀保证按字母序最后加载,不被其他规则覆盖
- 文件名用 `<user>-nopasswd` 而非通用名,避免被 vagrant / ansible 等其它工具覆盖

验证(让 Hermes 在自家跑):
```bash
sudo -n whoami        # 应回 root
sudo -n -l            # 应见 "(ALL) NOPASSWD: ALL"
```
verify 通过后,这一步配套写进 MEMORY.md,内容形如:`主机 <host> 上 <user> 用户的 sudo 已(...). 任何 sudo 操作不再弹密码;已验证 sudo -n whoami = root.`

### Step C — 主机自描述报告(可选但推荐)

一次性脚本,跑完贴回报。详见 `scripts/host-introspect.sh`(本 skill 自带)。输出四块:硬件 / 系统 / 依赖 / 端口服务。

为后续 remote dispatch 做基线档案(`references/host-profile-lan-fnubuntu.md` 是示例快照)。

## 3. Pitfalls

### P1: `sudo -S` / stdin 密码注入被永久拦截

Hermes Agent 平台层禁止 `sudo -S <<< "<password>"` / `echo $password | sudo -S`,无论密码是从用户消息、`.env`、stdin 任何一个来源调入。两种不同错报:
- `BLOCKED: sudo password guessing via stdin (sudo -S). Do not set up brute-force attack vector.` — 这是 prompt guard 拦截,直接拒绝执行。
- 拦截发生在 Hermes 内部执行,不是上报给 user 让 user 点确认。

**Lesson**:以后任何需要 sudo 的脚本,永远优先「用户先写 sudoers NOPASSWD」这条路径;secret 放 `.env` 仅作 Hermes 内部发起的 prompt 用。不要尝试绕过 (管道 / base64 / expect / alias),都会触发同一条拦截。

### P2: 改 config 不要直接 sed YAML

`hermes config set` 会做类型校验和自动迁移;直接 patch YAML 可能改出 `subagent_auto_approve: True` 大写布尔让校验器不认,下次 `hermes config check` 报 "missing key" 但运行时仍按旧默认值,出现"改了不生效"的错觉。

### P3: env_passthrough 用单引号外加 YAML 数组

如果用双引号包内嵌双引号,YAML 解析会变成字符串 `"['PATH']"` 而不是数组。一定要:
```bash
hermes config set terminal.env_passthrough '["PATH","HOME","LANG","LC_ALL","USER","SSH_AUTH_SOCK","TERM"]'
```
单引号外层,JSON 数组字符串内层。

### P4: `human_delay.mode=off` 默认就是 off,不用动

老黎看到这一项才发现原本就 off。改之前先 `python3 -c "import yaml; print(yaml.safe_load(open('/home/lan/.hermes/config.yaml'))['human_delay'])"` 看一眼现状,不要无脑设。

### P5: `hermes config check` 报缺密钥,绝大多数不是真的缺

那台机器没用企业微信 / Teams / ntfy / Slack-bot 直接对接,缺 `WECOM_*` / `TEAMS_*` / `NTFY_*` / `SLACK_BOT_TOKEN` 都是正常现象。`check` 输出末尾一堆 `○ SECRET_NAME` 但 `exit_code = 0` 才算通过,别被吓到。

### P6: `delegation.max_concurrent_children=3` 是当前 profile 上限

如果下次发现 delegate_task 调度慢/不并行,先看 profile 是否被改到 >3。`max_spawn_depth=2` 是平台默认上限,改到 3 + 也得明确知道后果(subagent 子级再派 agent,token 消耗指数级涨)。

## 4. When NOT to apply

- 不是刚装的机器:已有跑过的 Hermes config 已经在用,改之前先 dump 当前 `hermes config show` 给 user 看,user 点过头再动
- 多 profile 场景(同一个用户有 default / work / home 多个 profile):只改 user 显式指定的 profile,不要贪心全改
- 当 user 在第三方共享机 / 公司 dev VM 上:不要把 user 推到 `NOPASSWD: ALL`,改用最小权限白名单 sudoers 片段

## 5. Cross-references

- SOUL.md §1(信息真实性红线):做完一步验证一步,失败立即停
- USER.md §4(回复极度精简):汇报默认 dense 段落,合规不铺张
- AGENTS.md §3(verification before completion):45 行 config set 完必须 `hermes config check` + `sudo -n whoami` 双重 verify
- Companion: `coding-and-research-style` 管输出风格;本 skill 管执行回填

## Linked files

- `scripts/host-introspect.sh` — single-pass host probe (CPU / OS / deps / ports)
- `references/host-profile-lan-fnubuntu.md` — 2026-06-22 实例快照,作为后续 dispatch 的基线
