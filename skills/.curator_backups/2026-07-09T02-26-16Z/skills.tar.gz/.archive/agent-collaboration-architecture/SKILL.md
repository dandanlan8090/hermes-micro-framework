---
name: agent-collaboration-architecture
category: autonomous-ai-agents
description: >-
  Multi-agent collaboration architecture patterns — Hermes tri-agent orchestration (Hermes+OpenCode+OpenClaw),
  HCP protocol design, timeout/heartbeat/watchdog patterns, and integration paths (A/B/C).
  Use when designing, debugging, or extending multi-agent workflows.
created: 2026-06-27
version: 1.0
---

# Agent Collaboration Architecture

## Scope

This skill covers **multi-agent collaboration architecture** for Hermes-based systems:
- **Tri-agent pattern**: Hermes (orchestrator) + OpenCode (coding) + OpenClaw (script execution)
- **Communication protocols**: ACP (OpenClaw), HCP (Hermes Collaboration Protocol), STDIO/MCP
- **Reliability patterns**: Timeouts, heartbeat, watchdog, completion ACK, circuit breaker
- **Integration paths**: Three architectural choices (A: patch, B: hybrid, C: rewrite)

## When to Use

- Designing a new multi-agent pipeline
- Debugging stuck/hanging sub-agents
- Choosing between process vs. thread models
- Implementing timeout/heartbeat mechanisms
- Evaluating integration with OpenCode/OpenClaw

## Architecture Patterns

### Pattern 1: ThreadPoolExecutor (Legacy Hermes)

```
Hermes Parent
  ├─ ThreadPoolExecutor (threads, shared memory)
  ├─ Pipe communication (stdin/stdout, unidirectional)
  ├─ Stale detection (passive, 15/40 cycles)
  └─ completion_queue (no ACK, no persistence)
```

**Pros**: Simple, compatible with existing skills
**Cons**: Thread crashes kill parent, no isolation, no DAG

**Use when**: Low concurrency (<10 sub-agents), legacy compatibility required

---

### Pattern 2: Hybrid (Hermes + HCP) ✅ **Recommended**

```
Hermes Parent
  ├─ ThreadPoolExecutor (legacy threads)
  ├─ HCP Server (Unix socket, bidirectional JSON-RPC)
  ├─ Watchdog process (active probing, SIGTERM→SIGKILL)
  └─ SQLite state machine (persistence, DAG support)

Sub-Agent (HCP Client)
  ├─ Independent process
  ├─ Heartbeat every 30s via socket
  ├─ Responds to probe messages
  └─ Graceful shutdown on SIGTERM
```

**Pros**: Process isolation, bidirectional comm, active health checks, persistence
**Cons**: Moderate complexity, requires socket management

**Use when**: Building production multi-agent systems, need >10 concurrent sub-agents

---

### Pattern 3: Full Pipeline Orchestrator

```
Director Skill
  ├─ Pipeline YAML definition (input→agents→gates→output)
  ├─ DAG dependency resolution
  ├─ Conditional branching
  └─ Parallel merge with conflict detection
```

**Pros**: Maximum flexibility, declarative, supports complex workflows
**Cons**: 8-12 weeks to build, breaks existing skills

**Use when**: Building a general-purpose orchestration platform (not recommended for current needs)

---

## Timeout & Heartbeat Patterns

### P0: Hard Timeout (Code-Level Fix)

**Files Modified**:
- `tools/async_delegation.py`: Batch timeout 3600s, Queue retry 3x
- `tools/delegate_tool.py`: Child hard timeout 900s → 600s (updated 2026-06-27)
- `config.yaml`: `child_hard_timeout_seconds`, `batch_hard_timeout_seconds`

**Implementation**:
```python
# async_delegation.py
with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
    future = executor.submit(runner)
    try:
        combined = future.result(timeout=BATCH_HARD_TIMEOUT)
    except concurrent.futures.TimeoutError:
        logger.error("Batch timeout, killing...")
        if interrupt_fn:
            interrupt_fn()
```

**Configuration** (as of 2026-06-27):
```yaml
delegation:
  child_soft_timeout_seconds: 300      # 5 min: warn
  child_hard_timeout_seconds: 600      # 10 min: force interrupt
  child_max_timeout_seconds: 900       # 15 min: kill + abandon
  batch_soft_timeout_seconds: 900      # 15 min: warn
  batch_hard_timeout_seconds: 1800     # 30 min: force end
```

---

### P1: Watchdog Daemon

**File**: `~/.hermes/watchdog.py`

**Functionality**:
- Scans `~/.hermes/heartbeat/*.json` every 10s
- Stale threshold: 300s (5 min) without heartbeat
- Action: SIGTERM → wait 10s → SIGKILL
- Audit log: `~/.hermes/watchdog_audit.jsonl`

**Start**:
```bash
python3 ~/.hermes/watchdog.py --daemon
# or systemd: systemctl start hermes-watchdog
```

**Heartbeat File Format**:
```json
{
  "session_id": "20260627_143738_xxx",
  "last_heartbeat": 1782550814.123,
  "status": "running",
  "step": "reading_file",
  "progress_percent": 45
}
```

---

### P2: Completion ACK Protocol

**File**: `~/.hermes/completion_ack.py`

**Protocol**:
1. Sub-agent writes `~/.hermes/completions/<deleg_id>.json`
2. Parent polls, processes, writes `.ack` marker
3. Backup: `~/.hermes/pending_completions.jsonl` (for crash recovery)

**Message Format**:
```json
{
  "delegation_id": "deleg_xxx",
  "results": [...],
  "status": "completed",
  "written_at": "2026-06-27T14:37:59Z",
  "sequence_num": 42,
  "checksum": "sha256:abc123..."
}
```

---

## Integration Path Decision Matrix

| Path | Scheme | Effort | Risk | Benefit | Recommendation |
|------|--------|--------|------|---------|----------------|
| **A** | Patch existing | 1-2 weeks | Low | Medium | Short-term only |
| **B** | Hybrid (HCP) | 3-4 weeks | Medium | High | ✅ **Recommended** |
| **C** | Full rewrite | 8-12 weeks | High | Very High | ❌ Not now |

**Path B Implementation Roadmap**:
- **P0** (Week 1): Completion ACK enhancement (sequence_num + checksum)
- **P1** (Week 2-3): HCP protocol (Server + Client + probing)
- **P2** (Week 4): Watchdog enhancement + SQLite persistence
- **P3** (Optional): Circuit breaker + DAG dependencies

---

## Pitfalls

### 1. Sub-agent Timeout Too Long
**Symptom**: Sub-agents hang for 15+ minutes before being killed
**Root Cause**: Default `child_hard_timeout_seconds: 900` is too long for debugging
**Fix**: Reduce to 600s (10 min) for active development, increase to 900s for production long-running tasks

### 2. Completion Queue Lost on Crash
**Symptom**: Completed sub-agents not reported after parent restart
**Root Cause**: `completion_queue` is in-memory only
**Fix**: Write to `~/.hermes/pending_completions.jsonl` as backup, restore on startup

### 3. Watchdog Kills Legitimate Long Tasks
**Symptom**: Valid 10-minute tasks killed at 5-minute stale threshold
**Root Cause**: Heartbeat not updated during long operations
**Fix**: Sub-agent must update heartbeat every 30s even during long tool calls (use background thread)

### 4. OpenCode/OpenClaw Themselves Hang
**Symptom**: Both sub-agents timeout after 900s with 20+ API calls
**Root Cause**: They lack their own timeout configuration, their sub-sub-agents hang
**Fix**: Shorten Hermes child timeout to 600s, kill them before they waste tokens

---

## Verification Steps

After any multi-agent deployment:

1. **Test short task**:
   ```bash
   hermes delegate "echo hello"
   # Expected: completes in <30s
   ```

2. **Test timeout**:
   ```bash
   hermes delegate "sleep 700 && echo done"
   # Expected: killed at 600s (hard timeout)
   ```

3. **Test watchdog**:
   ```bash
   # Manually create stale heartbeat file
   echo '{"session_id":"test","last_heartbeat":0,"status":"running"}' > ~/.hermes/heartbeat/test.json
   # Wait 10s, check watchdog log
   tail ~/.hermes/watchdog.log
   # Expected: "Sending SIGTERM to PID..."
   ```

4. **Test completion ACK**:
   ```bash
   # Run delegation, check completions dir
   ls ~/.hermes/completions/
   # Should see .json and .json.ack pairs
   ```

---

## Related Files

- `references/p0-timeout-fix.md` — Detailed code patches for timeout protection
- `references/p1-watchdog-daemon.md` — Watchdog implementation details
- `references/hcp-protocol-spec.md` — HCP protocol specification draft
- `scripts/test-timeout.sh` — Automated timeout verification script

---

## Changelog

- **2026-06-27**: Initial creation — P0/P1/P2 fixes, Path B recommendation