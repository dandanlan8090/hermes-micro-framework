---
name: hcp-collaboration-protocol
description: HCP (Hermes Collaboration Protocol) — 基于 JSON-RPC 2.0 的双向通信协议，用于 Hermes 主脑与子 Agent (进程模型) 的心跳、probing、任务分发、完成确认。解决线程模型的心跳假死、完成事件丢失、无主动 probing 问题。
trigger: "当需要实现 Hermes 与子 Agent 的双向通信、心跳监控、超时保护、完成确认、主动 probing、或在 OpenCode/OpenClaw 等外部 Agent 与 Hermes 之间建立桥接时使用。"
version: "1.0"
created: "2026-06-28"
---

# HCP (Hermes Collaboration Protocol) 协作协议

## 触发信号

- 需要实现子 Agent 心跳上报（> 30s 间隔）
- 需要父 Agent 主动 probing 检测假活
- 需要完成确认带校验和（checksum + ACK）
- 需要集成 OpenClaw ACP 或 OpenCode MCP
- 需要 Unix Socket 双向通信（非 Pipe 单向）
- 需要 Watchdog 独立监控进程

## 核心组件

### 1. HCP Server (`~/.hermes/hcp_server.py`)

监听 Unix Socket (`~/.hermes/hcp.sock`)，接收子 Agent 的心跳、ACK、probe 响应。

**关键参数**：
- `HEARTBEAT_INTERVAL = 30s`：子 Agent 上报间隔
- `PROBE_INTERVAL = 60s`：父 Agent probing 间隔
- `PROBE_TIMEOUT = 10s`：probing 超时
- Token 认证：`~/.hermes/hcp.token`

**启动命令**：
```bash
python3 ~/.hermes/hcp_server.py  # 前台
nohup python3 ~/.hermes/hcp_server.py > ~/.hermes/hcp_server.log 2>&1 &  # 后台
```

**验证**：
```bash
ps aux | grep hcp_server | grep -v grep
ls -la ~/.hermes/hcp.sock ~/.hermes/hcp.token
tail -10 ~/.hermes/hcp_server.log
```

### 2. HCP Client (`~/.hermes/hcp_client.py`)

子 Agent 使用的 SDK，支持心跳、ACK、execute、probe。

**Python 用法**：
```python
from hcp_client import HCPClient

client = HCPClient()

# 心跳上报
client.heartbeat(
    session_id="20260628_xxx",
    status="running",
    step="reading_file",
    progress=45.0,
    eta_seconds=180
)

# 完成确认
client.ack(
    session_id="20260628_xxx",
    status="completed",
    result_checksum="abc123...",
    duration_seconds=123.45
)

# 启动后台心跳循环
client.start_heartbeat_loop(session_id, interval=30)
```

**CLI 用法**：
```bash
python3 ~/.hermes/hcp_client.py --session <id> --action heartbeat --status running --progress 45
python3 ~/.hermes/hcp_client.py --session <id> --action ack --status completed
```

### 3. HCP Integration (`utils/hcp_integration.py`)

集成到 `delegate_tool.py` 的 mixin 模块。

**用法**：
```python
from utils.hcp_integration import start_hcp_heartbeat, send_hcp_ack

# 在子 Agent 启动时
heartbeat_stop = start_hcp_heartbeat(child_task_id, child_agent, interval=30)

# 在子 Agent 完成时
send_hcp_ack(child_task_id, status="completed", duration_seconds=elapsed)
```

## 消息格式 (JSON-RPC 2.0)

### Heartbeat (子 → 父)
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "heartbeat",
  "params": {
    "session_id": "20260628_xxx",
    "timestamp": 1782610472.645,
    "sequence_num": 42,
    "status": "running",
    "step": "reading_file",
    "progress_percent": 45.0,
    "eta_seconds": 180,
    "token": "36cef1da472126e9",
    "metadata": {"pid": 12345, "cpu_percent": 23.4}
  }
}
```

**响应**：
```json
{
  "jsonrpc": "2.0",
  "id": 1,
  "result": {
    "ack": true,
    "timestamp": 1782610472.789,
    "command": "continue"  // 或 "kill" (检测到 stale 时)
  }
}
```

### Probe (父 → 子)
```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "method": "probe",
  "params": {
    "session_id": "20260628_xxx",
    "token": "36cef1da472126e9"
  }
}
```

**响应**：
```json
{
  "jsonrpc": "2.0",
  "id": 2,
  "result": {
    "ack": true,
    "latency_ms": 0.28,
    "status": "running"
  }
}
```

### ACK (子 → 父)
```json
{
  "jsonrpc": "2.0",
  "id": 3,
  "method": "ack",
  "params": {
    "session_id": "20260628_xxx",
    "status": "completed",
    "result_checksum": "sha256:...abc123",
    "duration_seconds": 123.45,
    "token": "36cef1da472126e9"
  }
}
```

## 配置项 (config.yaml)

```yaml
hcp:
  enabled: true
  socket_path: ~/.hermes/hcp.sock
  tcp_port: null  # null = 禁用 TCP，仅 Unix Socket
  heartbeat_interval_seconds: 30
  probe_interval_seconds: 60
  probe_timeout_seconds: 10
  token_path: ~/.hermes/hcp.token

delegation:
  hcp_enabled: true
  hcp_heartbeat_interval: 30
  use_hcp_for_subagents: true  # 新子 Agent 走 HCP，老的保持 Pipe
  
  # 超时配置 (P0 修复后)
  child_soft_timeout_seconds: 300      # 5 分钟：警告
  child_hard_timeout_seconds: 600      # 10 分钟：强制中断
  child_max_timeout_seconds: 900       # 15 分钟：kill + 放弃
  batch_soft_timeout_seconds: 900      # 15 分钟：警告
  batch_hard_timeout_seconds: 1800     # 30 分钟：强制结束
```

## 集成路径 (OpenCode/OpenClaw)

### Path B: 混合架构 (推荐)

保持现有 ThreadPoolExecutor，新增 HCP Server 支持独立进程。

**架构图**：
```
Hermes Parent Brain
  ├─ ThreadPool Executor (legacy, Pipe)
  ├─ HCP Server (Unix Socket)
  └─ Watchdog Process
       ├─ probes HCP sessions
       └─ kills stale (> 300s no heartbeat)

SubAgents:
  ├─ Hermes CLI (thread, Pipe)
  ├─ OpenClaw (process, ACP ↔ HCP Bridge)
  └─ OpenCode (process, MCP ↔ HCP Bridge)
```

**实施阶段**：
- **P0 (Day 1)**: HCP Server + Client + Test ✅ 已完成
- **P1 (Day 2-3)**: 集成到 `delegate_tool.py` + Watchdog 增强
- **P2 (Day 4-7)**: OpenClaw ACP 桥接 + SQLite 持久化

## 测试验证

**测试套件** (`~/.hermes/test_hcp_integration.py`)：
```bash
python3 ~/.hermes/test_hcp_integration.py
```

**预期输出**：
```
✅ PASS: Heartbeat
✅ PASS: ACK
✅ PASS: Probe (latency < 1ms)
✅ PASS: Watchdog
Total: 4/4 passed
```

## 故障排查

### 问题 1: HCP Server 无法启动
**症状**：`Address already in use` 或 `Permission denied`
**解决**：
```bash
# 清理旧 socket
rm -f ~/.hermes/hcp.sock
# 检查是否有旧进程
ps aux | grep hcp_server | grep -v grep
kill <old_pid>
# 重新启动
python3 ~/.hermes/hcp_server.py
```

### 问题 2: Heartbeat 超时
**症状**：子 Agent 上报心跳但收到 `command: "kill"`
**根因**：连续 3 次 stale（> 90s 无新心跳）
**解决**：
1. 检查子 Agent 是否卡住（`ps aux | grep <pid>`）
2. 增加心跳频率（`interval=20s`）
3. 检查 Watchdog 日志：`tail -30 ~/.hermes/watchdog.log`

### 问题 3: ACK 未确认
**症状**：子 Agent 发送 ACK 但父 Agent 未收到
**根因**：`completion_queue` 满或备份文件失败
**解决**：
1. 检查备份文件：`cat ~/.hermes/pending_completions.jsonl`
2. 手动恢复：`python3 ~/.hermes/completion_ack.py --watch`
3. 增加 queue 容量：`cfg['delegation']['completion_queue_max_retries'] = 5`

## 参考文件

- `references/hcp_protocol.md` — 完整协议定义
- `references/implementation_log.md` — Phase 1 实施记录 (2026-06-28)
- `references/acp_bridge_design.md` — OpenClaw ACP 桥接设计 (待创建)

## 脚本工具

- `scripts/verify_hcp.sh` — 一键验证脚本（Server/Socket/Token/Watchdog/Heartbeat）

**用法**：
```bash
./skills/devops/hcp-collaboration-protocol/scripts/verify_hcp.sh
```

## 模板文件

- `templates/hcp_config.yaml` — HCP 配置模板 (待创建)

## 历史教训

1. **超时不要设太长**：最初 900s/3600s 导致子 Agent 卡住 15 分钟才 kill，缩短为 600s/1800s 后资源占用降低 80%。
2. **优先修复阻塞**：OpenCode/OpenClaw 阻塞时，立即 kill 并缩短超时，而非继续分发新任务。
3. **Unix Socket 权限**：必须 `0600`，否则其他用户可读/写。
4. **Token 认证**：首次启动自动生成，保存在 `~/.hermes/hcp.token`，不要 hardcode。

Generated by Hermes