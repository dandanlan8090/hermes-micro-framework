---
name: coding-and-research-style
description: Use when producing analysis, research summaries, or implementation plans. Enforces output style for user lan — conclusions first, single-doc delivery, no decision-by-asking-back. Companion to SOUL.md §4-5.
---

# Coding & Research Output Style (lan preferences)

User (lan) has a low tolerance for fluff and strong opinions on output shape. This skill embeds those preferences so drafts start in shape — no rewrite pass needed.

## When to Apply

- Producing technical analysis or research summaries
- Drafting implementation plans or workflow proposals
- Summarizing any open-source project / framework to lan
- Writing scripts, configs, deployment plans for lan
- Any multi-section response where structure matters

## Core Output Rules

### 1. Conclusions first, structure skeleton, details slot in last
- Open with the answer / decision / verdict in the first 2-3 lines
- Then `## ` sections; never bury the conclusion after background
- Skip "Background", "What is X", "Why this matters" intros unless lan explicitly asks
- If a section can be cut without losing the answer, cut it

### 2. One document, not many
- Default = single Markdown file delivered once
- Never split into "introduction.md / plan.md / appendix.md" unless asked
- Inline code blocks must be complete + copy-pasteable. No "see above" or "fill in remaining"
- Stack entire scripts in one fenced block, never piecemeal across multiple snippets

### 3. No decision-by-asking-back
- Don't end drafts with "want me to do X?" or "should I proceed?"
- Pick the default, state it, do it
- If a real fork exists (3+ plausible directions), use `clarify` with ≤4 multiple-choice options — not open-ended prose
- "Should I...?" prompts make lan repeat themselves; respect that and choose

### 4. No term-of-art tutorial scaffolding
- Assume lan has the basics (Linux ops, AI Agent patterns, git, curl, docker)
- Do not explain what a Dockerfile is, what TDD means, what a hook is
- Do explain non-obvious choices lan would actually want to second-guess
- Cut the "this is important because..." paragraphs

### 5. Verdicts over hedges
- "可能是 / 似乎 / 我猜" = refuse to commit. Don't write.
- If the verdict is uncertain, say "不能确认 X 因为 Y" — fact, not hedge
- Bold the recommendation out of a small comparison; don't make user pick from 3 paragraphs

### 6. Section discipline
- ≤ 3 levels of headings
- No empty paragraphs as filler / breath / transitionals
- Code blocks come with their own short preface (why) and verification (how to confirm)
- Tables OK, bullet walls OK; if a list runs > 7 items, group hierarchically

## Pitfalls (what triggered this skill)

### P1: Research overflow on framework reconnaissance
Lan asked about a project, I fetched all 13 SKILL.md files end-to-end, drafted a 3000+ line analysis with phased roadmap. Lan reply: "空中楼阁居多，还不如总结成 AGENTS.md 更有效率."

**Lesson**: When user asks "看一下 X 项目", the deliverable is not exhaustive analysis. It's either a one-page verdict on fit, or a decisive recommendation (use / fork / skip) with reasoning — NOT a 12-section walkthrough.

### P2: Trailing "want me to...?" prompts
Multiple turns ended with "要不要现在开搞?". Lan prefers action over confirmation.

**Rule**: When the next step is clear (file path exists, tool available, decision reversible within 1 file), just do it. Save `clarify` for genuine forks (3+ choices, irreversible ops, conflicting requirements).

### P3: Drafting as analysis when inventory is empty
User asked a question touching many skills / many possible answers, I drafted a multi-skill migration map. Lan didn't want the map — they wanted a single artifact.

**Rule**: Plan format ("here's how we'd do X across N skills") is itself a deliverable candidate. Ask whether user wants plan vs. artifact only when truly ambiguous.

### P4: Re-explaining SOUL.md constraints
SOUL.md says "code must be full scripts", "include verification commands". Lan's read still flags when I leave those out. Means SOUL.md text alone is not load-bearing when drafting — this skill is.

### P5: Plan-with-fake-subcommands validates with a bang
Agent-Reach 集成那一轮,plan 写了 `agent-reach read <url>` 与 `agent-reach search-v2ex` 两个子命令做端到端验证;这两个子命令在 `agent-reach --help` 里根本不存在(项目本身故意不做 read/search 包装层)。落到执行 T4.1 / T4.4 才补上「改走 Jina / curl 直连」,验证表能补全,但中间多花了两轮 round-trip。

**Rule**: plan 里只要写「调某 CLI 的 X 子命令」,第一步要么跑 `command --help` 拿实际子命令清单压入 plan,要么在 plan §验证总表里加一行「CLI surface = <paste of --help>」。CLI 没出现在 --help 的就不写。详细规则见 `software-development/plan` skill 的「Step 0.A CLI surface check」。

### P6: Wrap-up 必须点出 plan vs 实际的偏差
lan 偏好是直接、由数据复证。「实际 × ×,plan × ×」的项要明列,不能合并成一句话「全部完成」。完成报告里固定三块:
- `实际做到`:实际跑通的命令 + 实际获取的数据
- `plan 与实际偏差`:plan 写了什么、实际怎么修改的、为什么改
- `未做到`:归因(超出 scope / 项白不好搬 / 上游 BUG,各自一类)

只写「全部办好 ✅」会被打回,lan 的错误容忍阈值低。

## Cross-references
- SOUL.md §3 (complete scripts), §4 (single doc), §5 (no fluff): this skill makes these drafting-load-bearing, not advisory
- USER.md §4 (lan response style): this skill is the HOW; USER.md is the WHAT
- Companion skill: `coding-external-research-fetch` handles the research input side

## When NOT to apply
- Memory/dump-only responses (one fact, no decisions)
- Pure tooling commands (just run them)
- When lan explicitly says "write more detail" / "展开讲讲"
