---
name: openclaw
description: "Delegate script execution and batch operations to OpenClaw CLI (agent --local mode)."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [Execution-Agent, OpenClaw, Script-Runner, Batch-Ops, Automation]
    related_skills: [opencode, claude-code, codex]
---

# OpenClaw CLI

Use [OpenClaw](https://github.com/openclaw/openclaw) as an autonomous script execution worker. OpenClaw specializes in **one-shot task execution** with embedded AI models, ideal for batch operations, log analysis, data cleaning, and system automation.

## When to Use

- User explicitly asks to use OpenClaw
- Need to execute bounded scripts/commands with AI interpretation
- Batch log analysis, data processing, or system surveys
- Tasks requiring command output capture and structured JSON results
- **Not for**: interactive coding sessions, multi-turn code review (use OpenCode instead)

## Prerequisites

- OpenClaw installed: `npm i -g openclaw` or via package manager
- Config initialized: `openclaw configure` (or auto-initialized on first run)
- Verify: `openclaw --version` and `openclaw doctor`
- Gateway running locally (default: port 18789, loopback)

## Binary & Config Paths

```bash
# Binary location
which openclaw  # Typically ~/.local/bin/openclaw

# Config directory
~/.openclaw/
├── openclaw.json        # Main config (gateway, models, tools)
├── agents/              # Agent sessions
├── workspace/           # Execution workspace
└── cache/               # Model cache
```

## Primary Mode: `agent --local` (Recommended)

**This is the simplest and most stable connection method** — no extra authentication needed, inherits local config.

### Basic Usage

```bash
openclaw agent --local \
  --session-id "<unique-id>" \
  --message "<task description>" \
  --json
```

### Hermes Delegation Pattern

```python
delegate_task(
    goal="批量分析系统日志",
    context="""
    使用 openclaw agent --local 模式执行:
    
    openclaw agent --local \\
      --session-id "hermes-$(date +%s)" \\
      --message "分析 /var/log/syslog 最近 1000 行，找出所有 ERROR 条目并汇总" \\
      --json
    
    工作目录：/home/lan
    超时：120 秒
    解析 JSON 输出中的 payloads[0].text
    """,
    toolsets=["terminal"],
    role="leaf"
)
```

### Output Structure

```json
{
  "payloads": [
    {
      "text": "执行结果输出",
      "mediaUrl": null
    }
  ],
  "meta": {
    "durationMs": 30258,
    "agentMeta": {
      "sessionId": "hermes-test",
      "provider": "agnes",
      "model": "agnes-2.0-flash",
      "usage": {
        "input": 33824,
        "output": 33,
        "total": 16931
      }
    }
  }
}
```

**Parse with**: `payloads[0].text` contains the execution result.

### Common Task Patterns

#### 1. Log Analysis

```bash
openclaw agent --local \
  --session-id "log-analysis-$(date +%s)" \
  --message "分析 /var/log/auth.log 最近 500 行，找出所有失败登录尝试并汇总 IP 地址" \
  --json
```

#### 2. System Survey

```bash
openclaw agent --local \
  --session-id "system-survey-$(date +%s)" \
  --message "执行以下命令并整理为 Markdown 表格：
1. uname -a
2. free -h
3. df -hT | grep -v tmpfs
4. ip -br addr show
保存结果到 /tmp/system-info.md" \
  --json
```

#### 3. Batch Service Initialization

```bash
openclaw agent --local \
  --session-id "service-init-$(date +%s)" \
  --message "安装并初始化 Redis:
1. sudo apt-get install -y redis-server
2. sudo systemctl enable --now redis-server
3. redis-cli ping
输出每个步骤的执行结果，标注成功 [✅] 或失败 [❌]" \
  --json
```

#### 4. File Processing

```bash
openclaw agent --local \
  --session-id "data-cleanup-$(date +%s)" \
  --message "读取 /tmp/large-log.txt，过滤出所有包含 ERROR 的行，统计每种错误类型的出现次数，保存为 /tmp/error-summary.txt" \
  --json
```

## Alternative Modes

### ACP Bridge Mode (Advanced: Hermes ↔ OpenClaw Agent Collaboration)

**Purpose**: True Agent-to-Agent delegation where OpenClaw acts as ACP client and Hermes acts as ACP server, exposing **full Hermes toolset** (terminal, file, browser, cron, skills, delegation, memory) to OpenClaw.

**Full documentation**: `skill_view(name="openclaw", file_path="references/acp-bridge.md")`

**Architecture**:

```
OpenClaw (ACP Client)
    ↓ stdio
Hermes ACP Server
    ↓ full tool access
Hermes Agent (nvidia/OpenRouter model)
```

**Setup**:

```bash
# 1. Start Hermes ACP server (REQUIRED - must run first)
hermes acp --accept-hooks

# 2. Verify Hermes ACP is running
ps aux | grep "hermes acp" | grep -v grep
# Expected: PID running /home/lan/.hermes/hermes-agent/venv/bin/python3 ... hermes acp

# 3. Start OpenClaw ACP client connected to Hermes
openclaw acp client --server "hermes" --cwd /home/lan -v

# Output:
# [acp-client] spawning: hermes acp
# [acp-client] initializing
# [INFO] acp_adapter.server: ACP client connected
# [INFO] acp_adapter.server: Initialize from openclaw-acp-client (protocol v1)
# OpenClaw ACP client
# Session: <uuid>
# Type a prompt, or "exit" to quit.
```

**Test Command**:

```bash
timeout 90 bash -c '
echo "Execute: echo ACP_TEST_OK" | \
openclaw acp client --server "hermes" --cwd /home/lan 2>&1
' | grep -E "ACP_TEST_OK|session"
```

**Verified Connection** (2026-06-30):

```
[INFO] acp_adapter.server: ACP client connected
[INFO] acp_adapter.server: Initialize from openclaw-acp-client (protocol v1)
[INFO] run_agent: OpenAI client created (agent_init, shared=True) provider=nvidia model=qwen/qwen3.5-397b-a17b
[INFO] acp_adapter.session: Created ACP session 4be1011d-0314-42f3-bc0b-107dbe6c2c22 (cwd=/home/lan)
OpenClaw ACP client
Session: 4be1011d-0314-42f3-bc0b-107dbe6c2c22
> 
[commands] /help /model /tools /context /reset /compact /steer /queue /version
```

**Key Advantages over `agent --local`**:

1. **Full Hermes capability**: Access to ALL Hermes tools (terminal, file, browser, cron, delegation, skills, memory, session_search)
2. **Session persistence**: ACP sessions persist to Hermes SessionDB (`~/.hermes/state.db`), survive restarts
3. **Context continuity**: Multi-turn conversations with full history
4. **Skill loading**: Hermes loads relevant skills automatically
5. **Memory integration**: Cross-session memory and user profile injected

**Limitations**:

1. **Interactive TUI**: `openclaw acp client` enters interactive mode (`> ` prompt), requires PTY or `process` tool for automation
2. **Command syntax**: Use `--server "hermes"` (NOT `--server-args "acp"` which causes `hermes acp acp` duplication)
3. **Initial latency**: ~5-7s for Hermes startup + model initialization
4. **Model dependency**: Requires configured Hermes model provider (nvidia/OpenRouter/etc.)
5. **Hermes ACP must run first**: If Hermes ACP server is not started, OpenClaw connection fails silently

**Common Mistake - MCP vs ACP**:

⚠️ **OpenClaw does NOT have `mcp serve` command**. This is a common misconception.

```bash
# ❌ WRONG - This command does NOT exist
openclaw mcp serve
# Error: Unknown command: openclaw mcp serve

# ✅ CORRECT - Use ACP for Hermes ↔ OpenClaw collaboration
openclaw acp client --server "hermes"

# ✅ CORRECT - Use agent --local for one-shot tasks
openclaw agent --local --message "task"
```

**Architecture Clarification** (2026-06-30 verified):

| Direction | Protocol | Command | Purpose |
|-----------|----------|---------|---------|
| **OpenClaw → Hermes** | ACP | `openclaw acp client --server "hermes"` | OpenClaw uses Hermes tools (full toolset) |
| **Hermes → OpenClaw** | CLI | `openclaw agent --local -m "task"` | Hermes delegates to OpenClaw (script execution) |
| **External → OpenClaw** | MCP | `openclaw mcp serve` | Exposes OpenClaw Channels (messaging only, NOT for script execution) |
| **External → Hermes** | MCP | `hermes mcp serve` | Exposes Hermes conversations/gateway to external MCP clients (e.g. OpenCode) |

**Hermes MCP Server** (for OpenCode integration):

Hermes can run as an MCP server to expose its messaging gateway conversations to external MCP clients like OpenCode, Claude Code, or Cursor:

```bash
# Start Hermes as MCP server (stdio mode - expects JSON-RPC input)
hermes mcp serve --verbose

# MCP server provides these tools:
# - conversations_list: List all messaging conversations
# - conversation_get: Get message history for a conversation
# - messages_read: Read messages from a conversation
# - messages_send: Send messages via connected platforms
# - events_poll: Poll for new events from platforms
# - channels_list: List all connected platform channels
# - permissions_list_open: List pending approval requests
# - permissions_respond: Respond to approval requests
```

**Important**: `hermes mcp serve` uses **stdio protocol** — it does NOT listen on a TCP port. It expects JSON-RPC messages via stdin and responds via stdout. External clients (OpenCode, etc.) spawn it as a subprocess and communicate via pipes.

**OpenCode config example** (add to OpenCode's MCP config):

```json
{
  "mcpServers": {
    "hermes": {
      "command": "hermes",
      "args": ["mcp", "serve"]
    }
  }
}
```

**Connection verification**:

```bash
# Hermes ACP server (for OpenClaw):
ps aux | grep "hermes acp" | grep -v grep
# Expected: Running process with hermes acp

# Hermes MCP server: Does NOT show as listening port (stdio only)
# Test by running: hermes mcp serve --verbose
# Should see: DEBUG:mcp.server.lowlevel.server:Initializing server 'hermes'
```

**Hermes Delegation Pattern (PTY Required)**:

```python
# Start ACP session in tmux
terminal(command="tmux new-session -d -s 'hermes-acp' 'openclaw acp client --server hermes --cwd /home/lan'", timeout=10)

# Wait for initialization
terminal(command="sleep 8", timeout=10)

# Send prompt
terminal(command="tmux send-keys -t 'hermes-acp' 'Analyze /var/log/syslog for errors' Enter", timeout=5)

# Wait for execution
terminal(command="sleep 60", timeout=65)

# Capture output
terminal(command="tmux capture-pane -t 'hermes-acp' -p | tail -100", timeout=5)

# Cleanup
terminal(command="tmux send-keys -t 'hermes-acp' 'exit' Enter && sleep 2 && tmux kill-session -t 'hermes-acp'", timeout=5)
```

**Decision Tree**:

```
Task type?
├─ Quick one-shot script/commands (< 60s)
│   └─ ✅ `openclaw agent --local` (recommended)
│
├─ Complex multi-turn Agent collaboration
│   └─ ✅ `openclaw acp client --server hermes` + tmux wrapper
│
├─ Need Hermes memory/skills/cron integration
│   └─ ✅ `openclaw acp client --server hermes`
│
└─ Simple log analysis/batch ops
    └─ ✅ `openclaw agent --local`
```

**Pitfalls Discovered (2026-06-24)**:

- **`--server-args "acp"` causes command duplication**: OpenClaw executes `hermes acp acp` instead of `hermes acp`. **Correct syntax**: `--server "hermes"` (OpenClaw auto-appends `acp`).
- **Interactive TUI doesn't consume piped input**: `echo "prompt" | openclaw acp client` doesn't work. **Workaround**: Use tmux or `process` tool for interactive sessions.
- **Hermes ACP uses custom protocol**: Not standard ACP `tasks/create`. Uses `session/create` + message stream.
- **Session ID format**: UUID v4 format (e.g., `ec25e239-f1b7-45e1-9fc3-145c196f577d`).

### MCP Server Mode (For External Clients)

```bash
openclaw mcp serve
```

**Purpose**: Exposes OpenClaw **Channels** as MCP tools (conversations_list, messages_send, etc.) — lets external MCP clients (Claude Desktop, etc.) control OpenClaw's messaging platform integrations.

**Not for**: Script execution or task delegation.

**Tested JSON-RPC flow**:

```bash
# Initialize handshake
echo '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"test","version":"1.0"}}}' | \
  openclaw mcp serve

# Query available tools
echo '{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}' | \
  openclaw mcp serve

# Output: conversations_list, conversation_get, messages_read, attachments_fetch, events_poll, events_wait, messages_send, permissions_list_open, permissions_respond
```

**Verdict**: Useful for MCP ecosystem integration, but overkill for Hermes task delegation.

### Gateway WebSocket Mode (Advanced)

```bash
# Config: ~/.openclaw/openclaw.json
{
  "gateway": {
    "mode": "local",
    "port": 18789,
    "bind": "loopback",
    "auth": {"mode": "token", "token": "..."}
  }
}
```

**Use case**: Remote OpenClaw instances, multi-user setups.

**Verdict**: Unnecessary for single-user local automation.

## Configuration Reference

### Gateway Config (`~/.openclaw/openclaw.json`)

```json
{
  "agents": {
    "defaults": {
      "workspace": "/home/lan/.openclaw/workspace",
      "model": {
        "primary": "agnes/agnes-2.0-flash"
      }
    }
  },
  "gateway": {
    "mode": "local",
    "auth": {
      "mode": "token",
      "token": "3e4d...c39b"
    },
    "port": 18789,
    "bind": "loopback"
  },
  "tools": {
    "profile": "coding"  // Limits dangerous tools (sms.send, camera.snap, etc.)
  }
}
```

### Tool Profiles

| Profile | Tools Included | Restrictions |
|---------|---------------|--------------|
| `coding` | exec, file_read, file_write, search, patch | Blocks: sms.send, camera.*, contacts.*, calendar.* |
| `full` | All tools | No restrictions |
| `safe` | Read-only tools | No write/execute |

**Default**: `coding` (safe for automation).

## Procedure

1. **Verify readiness**:
   ```bash
   terminal(command="openclaw --version")
   terminal(command="openclaw doctor")
   ```

2. **Delegate task**:
   ```python
   delegate_task(
     goal="<task>",
     context="openclaw agent --local --session-id '<id>' --message '<prompt>' --json",
     toolsets=["terminal"]
   )
   ```

3. **Parse output**:
   ```python
   import json
   result = json.loads(output)
   text = result.get('payloads', [{}])[0].get('text', '')
   ```

4. **Verify execution**:
   - Check exit code
   - Validate expected files created/modified
   - Run verification commands (`systemctl status <svc>`, `ss -tuln | grep <port>`)

## Pitfalls

- **Session ID collision**: Always use unique `--session-id` to avoid state pollution. Use `hermes-$(date +%s)` or UUID.
- **Timeout limits**: Default 600s. Use `timeout <N>` wrapper for bounded tasks.
- **JSON parsing**: Output may include extra stdout (logs, warnings). Use `grep -A` or parse from end of output.
- **Permission prompts**: Sudo commands or file writes may request user approval. Not automatable without `-y` flags or pre-configuration.
- **Unicode confusables**: Security scanner may flag output. Requires user approval for flagged commands.
- **Model selection**: Default is `agnes-2.0-flash`. Override with `--model <provider/model>` if needed.
- **File write paths**: OpenClaw defaults to `~/.openclaw/workspace/`. Use absolute paths for other locations.

## Verification

Smoke test:

```bash
openclaw agent --local \
  --session-id "smoke-test-$(date +%s)" \
  --message "执行：echo 'OPENCLAW_SMOKE_OK' 并只返回这个输出" \
  --json

# Expected output:
# "payloads": [{"text": "OPENCLAW_SMOKE_OK"}]
```

Success criteria:
- JSON parseable
- `payloads[0].text` contains expected output
- Exit code 0

## Rules

1. **Always use `agent --local`** for Hermes delegation — simplest, most stable.
2. **Unique session IDs** per invocation to prevent state collision.
3. **Parse JSON output** — extract `payloads[0].text`, don't use raw stdout.
4. **Set explicit timeouts** — long-running tasks need `timeout <N>` wrapper.
5. **Verify critical operations** — don't trust self-reported success; run actual checks.
6. **Scope tasks narrowly** — one OpenClaw call = one bounded task, not a multi-hour project.

## Comparison with OpenCode

| Aspect | OpenClaw (`agent --local`) | OpenCode (`--attach tcp://...`) |
|--------|---------------------------|--------------------------------|
| **Primary use** | Script execution, batch ops | Code development, refactoring |
| **Connection** | CLI (no setup) | TCP server (systemd managed) |
| **Session** | Stateless (new per call) | Stateful (long-lived) |
| **Model** | Embedded (`agnes-2.0-flash`) | Configurable (any provider) |
| **Output** | JSON (`payloads[0].text`) | Text/markdown (TTY) |
| **Best for** | Log analysis, init scripts, data cleaning | Code review, feature implementation, debug sessions |
| **Hermes pattern** | `delegate_task` → `terminal("openclaw agent --local ...")` | `delegate_task` → `terminal("opencode --attach ...")` |

**Three-Agent Architecture**:

```
Hermes-fn (主脑)
    ├─ delegate_task → OpenClaw (script execution, batch ops)
    └─ delegate_task → OpenCode (code collaboration, PR review)
```

## Troubleshooting

### "Session not found" error

**Cause**: Missing `--session-id` or invalid session reference.

**Fix**: Always provide `--session-id "<unique-id>"`.

### JSON parse failure

**Cause**: Output includes extra stdout/logs before JSON.

**Fix**: Extract JSON from output:

```bash
output | tail -n +$(grep -n '^{' <<< "$output" | head -1 | cut -d: -f1) | python3 -c "import sys,json; print(json.load(sys.stdin))"
```

### Timeout (600s exceeded)

**Cause**: Complex task took too long.

**Fix**: Split into smaller tasks or increase timeout:

```bash
timeout 300 openclaw agent --local --message "<task>" --json
```

### Permission denied (sudo)

**Cause**: Sudo requires approval.

**Fix**: Use non-interactive sudo flags, or pre-instructions:

```bash
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y <package>
```

### Model provider errors

**Cause**: Agnes API key missing or expired.

**Fix**: Check `~/.openclaw/openclaw.json` → `models.providers.agnes.apiKey`.