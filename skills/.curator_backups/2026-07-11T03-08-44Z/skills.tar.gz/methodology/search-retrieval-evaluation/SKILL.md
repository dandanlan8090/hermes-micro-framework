---
name: search-retrieval-evaluation
description: >-
  搜索/检索系统质量评估方法论。覆盖：benchmark query 集构建、融合策略 A/B 对比
  (RRF vs 加权融合)、Top-1/Top-3 命中率测量、逐案差异分析、分阶段演进 (P0→P1→P2)。
  配套 Hermes vdb 检索基准测试。
version: 1.0.0
author: Hermes Agent
license: MIT
platforms:
  - linux
  - macos
  - windows
metadata:
  hermes:
    tags:
      trigger:
        - benchmark
        - 检索评估
        - 检索评测
        - retrieval evaluation
        - search quality
        - RRF 对比
        - 融合策略
        - 命中率
        - top1
        - top3
        - recall test
        - search benchmark
        - 检索对比
        - A/B 测试
        - 融合评测
      disable:
        - deep_review
        - code_development
    skill_type: methodology
    priority: high
    depends_on:
      - vdb-retrieval-pipeline
---

# search-retrieval-evaluation — 检索质量评估与融合策略对比

## 背景

Hermes 的 vdb 混合检索使用 `0.6 × dense + 0.4 × sparse` 线性加权融合。  
2026-07-11 对 RRF (Reciprocal Rank Fusion) 做了基准对比，发现 RRF 在 Top-1 上领先 3.3pp。

本 skill 记录如何搭建检索评估、运行对比、以及逐步改进的流程。

## 评估方法论

### 构建 benchmark query 集

Benchmark 应由三种 query 类型组成：

1. **路由表场景** — 命中 `§技能路由表` 的关键词（最真实）
2. **中文场景** — 用户实际可能输入的碎片化口语 query
3. **英文场景** — 保留触发词原样，验证跨语言召回

每条 query 配一个 **期望 skill 名**。期望 skill 应是通过语义或关键词最匹配的那个。

61 条 query / 45 skill 的 benchmark 参考 `references/benchmark-case-set.md`。

### 对比脚本结构

```
query → Chroma dense top-16 (含 dense_score, metadata)
     │
     ├─ 0.6/0.4 融合: final = 0.6*dense + 0.4*sparse → 排序 → top-1/3
     │             命中 = expected in top-1/3
     │
     └─ RRF 融合:   dense_rank = Chroma 序 (1..16)
                    sparse_rank = 候选内 sparse_score 排序 (1..N)
                    rrf_score  = 1/(k + dense_rank) + 1/(k + sparse_rank)
                    k = 60 (TencentDB 取值, 也可调参)
                    → 排序 → top-1/3
                    命中 = expected in top-1/3
```

逻辑保留 `dense_score`, `sparse_score`, `dense_rank`, `sparse_rank`, `rrf_score` 供差异分析。

完整可运行脚本在 `scripts/benchmark_rrf.py`。

### 指标

- **Top-1 命中率** — 最重要的单一质量指标
- **Top-3 命中率** — 副指标，检索卡可以容忍前 3 中有正确答案
- **逐案差异** — 分析两种融合策略的不一致 case，判断谁更「对」

### 差异解构方法

对 Top-1 不一致的 case：查看哪个结果更符合语义。常见模式：

| 模式 | RRF 赢 | 基线赢 |
|------|--------|--------|
| sparse 分把高 TF 的干扰 skill 推上前排 | RRF 的 rank-only 抑制了这种干扰 | 基线吃到了高位 dense 分 |
| 期望 skill dense 分中高但不在第 1，sparse 分中下 | RRF 通过 rank 加权把它抬到第 1 | 基线 linear 权重不足 |
| 期望 skill 名称/trigger 和 query 高度不匹配 | — | 基线 dense 语义匹配胜出 |

## P0→P1→P2 分阶段演进

这是对 vdb（或其他检索系统）进行安全迭代的推荐流程：

### P0：只评估，不动线上

1. 构建 benchmark case 集（可复用现有技能列表）
2. 写离线对比脚本，读 Chroma 数据但不改任何线上文件
3. 跑一次，输出 Top-1/Top-3 命中率差异
4. 做差异解构，判断新策略是否值得推进

**产出**：benchmark 结果 + 差异分析 + 决策（推/不推）

### P1：如果新策略胜出，只 patch 融合层

1. 只改 `matcher.py` 的 score 计算段
2. 保留 `dense_score`/`sparse_score` 独立字段输出
3. 新字段 `rrf_score` 用于调试，`final_score` 保持命名兼容
4. 重跑 benchmark 确认指标不退化

**受影响文件**（极小改动面）：
- `matcher.py` — 融合算法行
- `matcher.py` 顶部常量 — 删或保留旧权重注释

### P2：稀疏检索增强（不引入 jieba/FTS5）

1. build_index 时写入全局 token df/idf
2. sparse score 从纯 cosine lexical 改成 TF-IDF lexical
3. 不引入 jieba（触发词已是最优关键词切割）
4. 不引入 BM25 服务（零新增依赖）
5. 重跑 benchmark 确认指标不退化

## 依赖

- `vdb-retrieval-pipeline`（被评估的目标系统）
- `chromadb`, `openai`, `python-dotenv`（同 vdb 依赖）

## 验证

运行 benchmark 脚本验证指标与上次基准持平或提升：
```bash
source ~/.hermes/vdb/.venv/bin/activate
python3 eval/benchmark_rrf.py
```

脚本位置：`~/.hermes/vdb/eval/benchmark_rrf.py`（与 vdb 同目录，非 skill 内复制）
